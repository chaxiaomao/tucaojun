
			<p align="center"><?php echo stripslashes(get_option('swt_top_c')); ?></p>
			<div class="clear"></div>
