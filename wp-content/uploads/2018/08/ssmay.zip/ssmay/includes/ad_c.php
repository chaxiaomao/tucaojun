<div class="adt">
		<div class="ad_t">
			<p align="center"><?php echo stripslashes(get_option('swt_ad_c')); ?></p>
			<div class="clear"></div>
		</div>
</div>