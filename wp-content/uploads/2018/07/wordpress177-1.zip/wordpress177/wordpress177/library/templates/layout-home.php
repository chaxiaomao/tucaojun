<?php 
$kopa_setting = kopa_get_template_setting();
$sidebars = $kopa_setting['sidebars'];
?>

<?php get_header(); ?>

<?php if ( is_active_sidebar( $sidebars[1] ) || is_active_sidebar( $sidebars[2] ) ) { ?>
    <div class="top-sidebar">
        
        <div class="wrapper">
            <div class="row-fluid">
                <div class="span12 clearfix">
                    <div class="l-col widget-area-2">
                        <div class="r-color"></div>
                        <?php if ( is_active_sidebar( $sidebars[1] ) ) {
                            dynamic_sidebar( $sidebars[1] );
                        } ?>
                    </div>
                    <!-- l-col -->
                    <div class="r-col widget-area-3">
                        <?php if ( is_active_sidebar( $sidebars[2] ) ) {
                            dynamic_sidebar( $sidebars[2] );
                        } ?>
                    </div>
                    <!-- r-col -->
                </div>
                <!-- span12 -->
            </div>
            <!-- row-fluid -->
        </div>
        <!-- wrapper -->
    </div>
<?php } ?>

<?php get_template_part( 'library/templates/template', 'headline' ); ?>

<?php if ( is_active_sidebar( $sidebars[3] ) || is_active_sidebar( $sidebars[4] ) ) { ?>
    <div class="light-block">
        
        <div class="wrapper">
            <div class="row-fluid">
                <div class="span12 clearfix">
                    <div class="l-col widget-area-12">
                        <div class="r-color"></div>
                        <?php if ( is_active_sidebar( $sidebars[3] ) ) {
                            dynamic_sidebar( $sidebars[3] );
                        } ?>
                    </div><!--l-col-->
                    <div class="r-col widget-area-13">
                        <?php if ( is_active_sidebar( $sidebars[4] ) ) {
                            dynamic_sidebar( $sidebars[4] );
                        } ?>
                    </div><!--r-col-->
                </div><!--span12-->
            </div><!--row-fluid-->
        </div><!--wrapper-->
    </div><!--light-block-->
<?php } ?>

<?php if ( is_active_sidebar( $sidebars[5] ) || is_active_sidebar( $sidebars[6] ) ) { ?>
    <div class="dark-block">
        
        <div class="wrapper">
            <div class="row-fluid">
                <div class="span12 clearfix">
                    <div class="l-col widget-area-14">
                        <div class="r-color"></div>
                        <?php if ( is_active_sidebar( $sidebars[5] ) ) {
                            dynamic_sidebar( $sidebars[5] );
                        } ?>
                    </div><!--l-col-->
                    <div class="r-col widget-area-15">
                        <?php if ( is_active_sidebar( $sidebars[6] ) ) {
                            dynamic_sidebar( $sidebars[6] );
                        } ?>
                    </div><!--r-col-->
                </div><!--span12-->
            </div><!--row-fluid-->
        </div><!--wrapper-->
    </div><!--dark-block-->
<?php } ?>

<?php if ( is_active_sidebar( $sidebars[7] ) || is_active_sidebar( $sidebars[8] ) ) { ?>
    <div id="main-content">
        
        <div class="wrapper">
            <div class="row-fluid">
                <div class="span12 clearfix">
                    <div class="l-col widget-area-6">                    
                        <div class="r-color"></div>
                        <?php if ( is_active_sidebar( $sidebars[7] ) ) {
                            dynamic_sidebar( $sidebars[7] );
                        } ?>
                        
                    </div>
                    <!-- l-col -->
                    
                    <div class="r-col widget-area-7">
                        
                        <?php if ( is_active_sidebar( $sidebars[8] ) ) {
                            dynamic_sidebar( $sidebars[8] );
                        } ?>
                        
                    </div>
                    <!-- r-col -->
                </div>
                <!-- span12 -->
            </div>
            <!-- row-fluid -->
        </div>
        <!-- wrapper -->
    </div>
    <!-- main-content -->
<?php } ?>

<?php get_footer(); ?>