WebFont.load({
    google: {
        families: ['Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic']
    }
});