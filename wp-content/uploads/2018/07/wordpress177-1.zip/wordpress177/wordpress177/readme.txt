Forceful theme
---------

Kindly refer to the "document/index.html" file inside your theme download package for installation and usage instructions.

Thanks!
KOPASOFT
