<div id="sidebar">
 
         
	<?php 
		if ( is_active_sidebar( 'sidebar' ) )
			dynamic_sidebar( 'sidebar');
	?>
	
       

	<div class="clear"></div>
	
	<div class="left-widget">
		<?php 
			if ( is_active_sidebar( 'sidebar-left' ) )
				dynamic_sidebar( 'sidebar-left');
		?>
	</div><!--end .left-widget-->
	
	<div class="right-widget">
		<?php 
			if ( is_active_sidebar( 'sidebar-right' ) )
				dynamic_sidebar( 'sidebar-right');
		?>
	</div><!--end .right-widget-->
	
</div><!--end #sidebar-->