<?php get_header(); ?>

<div id="container">
 <?php include (TEMPLATEPATH . '/includes/featured-posts.php'); ?>

	<div id="content">
             
<div id="gsearch">
<div id="gsearchform">	
<form action="http://www.google.com.hk/cse" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-6762001244735074:c2nf1w-je3k" />
    <input type="hidden" name="ie" value="GB2312" />
    <input type="text" name="q" size="31" />
    <input type="submit" name="sa" value="&#x641c;&#x7d22;" />
  </div>
</form>

<script type="text/javascript" src="http://www.google.com.hk/coop/cse/brand?form=cse-search-box&amp;lang=zh-Hans"></script>

</div>
<div id="gsearchkeyword">
</div>
<div class="clear"></div>
<div class="heading">
				<span class="heading-text"></span>
			</div> <!-- end .heading -->	
</div>
                
						
		<div class="gridrow clear">

			<?php 
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				$wp_query = new WP_Query('posts_per_page='.get_theme_mod('home_postnum').'&paged=' . $paged);
				if (have_posts()) {
				$counter = 0;
					while (have_posts()) : the_post();
						global $post;
						include(TEMPLATEPATH. '/includes/home-loop.php');
						
						if( $counter % 2 != 0 )
						echo'<div class="clear"> </div>';
						$counter++;

					endwhile;
				} else { 
					include(TEMPLATEPATH. '/includes/not-found.php'); 
				}
				
				if ( $wp_query->max_num_pages > 1 ) tj_pagenavi();
				wp_reset_query();
			?>
			
		</div>
		
	</div><!--end #content-->
	
	<?php get_sidebar(); ?>
	
</div><!--end #container-->


<?php get_footer(); ?>