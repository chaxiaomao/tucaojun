<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes( 'xhtml' ); ?>>
<head profile="http://gmpg.org/xfn/11">

<?php $the_title = wp_title(' - ', false); if ($the_title != '') : ?>
    <title><?php echo wp_title('',false); ?></title>
<?php else : ?>
    <title><?php bloginfo('name'); ?></title>
<?php endif; ?>

<?php if (is_home()){
    $description = "MAX、Maya、Houdini、Flash、Android、HTML5、CSS3... All in here";
    $keywords = "MAX、Maya、Houdini、Flash、Android、HTML5、CSS3... All in here";
} elseif (is_single()){
    if ($post->post_excerpt) {
        $description     = $post->post_excerpt;
    } else {
        $description = substr(strip_tags($post->post_content),0,120);
    }
 
    $keywords = "";       
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {
        $keywords = $keywords . $tag->name . ", ";
    }
}
?>
<meta name="keywords" content="<?php $keywords?>" />
<meta name="description" content="<?php $description?>" />

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<link rel="shortcut icon" href="<?php bloginfo( 'template_url' ); ?>/images/favicon.ico" />

	<?php wp_head(); ?>
	
	<script src="<?php bloginfo('template_directory'); ?>/js/jcarousel.js" type="text/javascript"></script>
	
	<!--begin of header code-->	
		<?php if(get_theme_mod('head_code_status') == "Yes") echo stripslashes(get_theme_mod('head_code')); ?>
	<!--end of header code-->
	
	<!--[if lt IE 7]>
	
	<style type="text/css"> 
		body {behavior:url("<?php bloginfo( 'template_url' ); ?>/js/csshover3.htc");}
	</style>
	
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/pngfix.js"></script>
	
	<script type="text/javascript">
			DD_belatedPNG.fix('#image-logo a, .backtotop');
	</script>
	
	<![endif]-->
	
</head>

<body <?php body_class(); ?>>

<?php if (is_home()) add_filter('img_caption_shortcode', create_function('$a, $b, $c','return $c;'), 10, 3); ?> 
<?php if (is_category()) add_filter('img_caption_shortcode', create_function('$a, $b, $c','return $c;'), 10, 3); ?> 

<div id="wrapper">

	<div id="top">			
		<?php if (get_theme_mod('social_status') == 'Yes') { ?>

		<?php } ?>
		
		<?php 
			$pagesNav = '';
			if (function_exists('wp_nav_menu')) {
				$pagesNav = wp_nav_menu( array( 'theme_location' => 'header-pages', 'menu_class' => 'topnav', 'menu_id' => 'page-nav', 'echo' => false, 'fallback_cb' => '' ) );};
			if ($pagesNav == '') { ?>
			<ul id="page-nav" class="topnav">
					<li<?php if(is_home() ) { ?> class="first"<?php } ?>><a class="first" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('description'); ?>"><?php _e('Home', 'themejunkie'); ?></a></li>
				<?php wp_list_pages('title_li=&exclude=412'); ?>
                               
			</ul>
		<?php }
			else echo($pagesNav); 
		?>
		

		<div id="search">
 
			<form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
				<input type="text" class="field" name="s" id="s"  value="<?php _e('Search this site...', 'themejunkie') ?>" onfocus="if (this.value == '<?php _e('Search this site...', 'themejunkie') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e('Search this site...', 'themejunkie') ?>';}" />
				<input id="searchsubmit" type="image" src="<?php bloginfo('template_directory'); ?>/images/ico-search.gif" value="Go" />
			</form>
		</div><!--end #search -->
                    			
		
		<div class="clear"></div>    	
    </div> <!--end #top-->
    	
	<div id="header">

		<?php 
			if(get_theme_mod('logo') == 'Image Logo') $logo_class = 'image-logo';
			if(get_theme_mod('logo') == 'Text Logo') $logo_class = 'text-logo';
		?>
		
		<?php if ( is_home() || is_front_page() ) echo '<h1'; else echo '<div'; echo ' class="logo" id="'.$logo_class.'">'; ?>
		
		<a <?php if(get_theme_mod('logo') == 'Image Logo' && get_theme_mod('logo_url')) {echo 'style="background:url('.get_theme_mod('logo_url').') no-repeat" ';} ?>href="<?php bloginfo('url'); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?> <span class="desc"><?php bloginfo( 'description' ); ?></span></a>
		
		<?php if ( is_home() || is_front_page() ) echo '</h1>'; else echo '</div>'; ?>

<!--BEGIN OF HEADER ADVERTISEMENT-->		
			<?php if(get_theme_mod('header_ad_status') == "Yes") { ?> 
				<div class="header-ad">			
					<?php echo stripslashes(get_theme_mod('header_ad')); ?>
				</div><!--end .header-ad-->
			<?php } ?>
<!--END OF HEADER ADVERTISEMENT-->		
		<div class="clear"></div>
		
	</div><!-- #header -->

	<div id="cat-menu">
	    	
		<?php 
			$catNav = '';
			if (function_exists('wp_nav_menu')) {
				$catNav = wp_nav_menu( array( 'theme_location' => 'header-cats', 'menu_class' => 'nav', 'menu_id' => 'cat-nav', 'echo' => false, 'fallback_cb' => '' ) );};
			if ($catNav == '') { ?>
				<ul id="cat-nav" class="nav">
					<?php wp_list_categories('title_li=&orderby=name&exclude=8'); ?>				
				</ul>
		<?php } else echo($catNav); ?>	 
		
	</div> <!--end #cat-nav-->
	
	<div id="main" class="clear">
	
		<?php if(is_home()) { ?>
	<?php } else { ?>

	<?php } ?>