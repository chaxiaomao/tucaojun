<?php get_header(); ?>

<div id="container">
	<div id="content">
	<div id="breadcrumb">
		<?php tj_breadcrumb(); ?>
	</div><!--end #breadcrumb-->
		<?php the_post(); ?>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						
			<h1 class="entry-title"><?php the_title(); ?></h1>
	                 <script type="text/javascript"><!--
google_ad_client = "ca-pub-6762001244735074";
/* 468&#42;15 */
google_ad_slot = "5446885012";
google_ad_width = 468;
google_ad_height = 15;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
			<div class="entry-meta">
				<span class="meta-author"><?php _e('Published by','themejunkie'); ?> <?php the_author_posts_link(); ?></span>
				<span class="meta-date"><?php _e( 'on ', 'themejunkie' ); ?><?php the_time(get_option('date_format')); ?></span> 
				<span class="meta-sep">|</span>
				<?php comments_popup_link('0 Comment','1 Comment','% Comment'); ?>
				<?php edit_post_link( __( 'Edit', 'themejunkie' ), '<span class="meta-sep">|</span> <span class="meta-edit">', '</span>' ); ?>
			</div> <!--end .entry-meta-->
			
			<!--BEGIN OF POST TOP CODE-->
			<?php if(get_theme_mod('post_top_code_status') == "Yes") echo stripslashes(get_theme_mod('post_top_code')); ?>
			<!--END OF POST TOP CODE-->

			<div class="entry entry-content">
				<?php the_content(); ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'themejunkie' ), 'after' => '</div>' ) ); ?>
			</div> <!--end .entry-->
			
			<div id="entry-bottom">
			<strong><?php _e( 'Category: ', 'themejunkie' ); ?></strong><?php the_category( ', ' ); ?> 
			<?php printf(the_tags(__('<span id="entry-tags"><strong>Tag:</strong>&nbsp;','themejunkie'),', ','</span>')); ?>
			</div>
<div id="adlink">
<div id="column1">
<?php echo tj_related_posts(); ?>
</div>
<div id="column1">

<script type="text/javascript"><!--
google_ad_client = "ca-pub-6762001244735074";
/* 300&#42;250 */
google_ad_slot = "8602746612";
google_ad_width = 300;
google_ad_height = 250;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>
<div class="clear"></div>
</div>

			<!--BEGIN OF POST BOTTOM CODE-->
			<?php if(get_theme_mod('post_bottom_code_status') == "Yes") echo stripslashes(get_theme_mod('post_bottom_code')); ?>
			<!--END OF POST BOTTOM CODE-->
                
<!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<span class="jiathis_txt">分享到：</span>
	<a class="jiathis_button_qzone">QQ空间</a>
	<a class="jiathis_button_tsina">新浪微博</a>
	<a class="jiathis_button_tqq">腾讯微博</a>
	<a class="jiathis_button_renren">人人网</a>
	<a class="jiathis_button_kaixin001">开心网</a>
	<a class="jiathis_button_douban">豆瓣</a>
	<a href="http://www.jiathis.com/share?uid=890875" class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank">更多</a>
</div>
<script type="text/javascript">var jiathis_config = {data_track_clickback:true};</script>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=890875" charset="utf-8"></script>
<!-- JiaThis Button END -->

                        <div id="wumiiDisplayDiv"></div>
			
			<?php if(get_theme_mod('display_related_posts') == 'Yes') { ?>
			<div class="entry-related">
				<?php echo tj_related_posts(); ?>
				<div class="clear"></div>
			</div>
			<?php } ?>
			
			<?php if(get_theme_mod('display_social_bookmarks') == 'Yes') { ?>

			<?php } ?>

			<div class="clear"></div>
			</div><!--end .entry-bottom-->
		
		<?php comments_template( '', true ); ?>
	</div><!--end #content -->
</div><!--end #container -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
