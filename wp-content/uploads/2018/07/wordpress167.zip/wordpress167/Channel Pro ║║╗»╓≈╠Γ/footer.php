</div><!--end #main-->
  
		<?php if ( is_active_sidebar( 'footer-widget-area-1' ) || is_active_sidebar( 'footer-widget-area-2' ) || is_active_sidebar( 'footer-widget-area-3' ) || is_active_sidebar( 'footer-widget-area-4' )) { ?>
		<div id="footer">
			<div class="widget" id="fwidget-1">
				<?php if ( is_active_sidebar( 'footer-widget-area-1' ) ) :  dynamic_sidebar( 'footer-widget-area-1'); endif; ?>
			</div>
	
			<div class="widget" id="fwidget-2">
				<?php if ( is_active_sidebar( 'footer-widget-area-2' ) ) :  dynamic_sidebar( 'footer-widget-area-2'); endif; ?>
			</div>
			
			<div class="widget" id="fwidget-3">
				<?php if ( is_active_sidebar( 'footer-widget-area-3' ) ) :  dynamic_sidebar( 'footer-widget-area-3'); endif; ?>
			</div>
		
			<div class="widget" id="fwidget-4">				
				<?php if ( is_active_sidebar( 'footer-widget-area-4' ) ) :  dynamic_sidebar( 'footer-widget-area-4'); endif; ?>
			</div>
                    
		</div>
		<?php } ?>
                   
                    <div id="footer">	
                  <b>热门标签</b>：<?php wp_tag_cloud('smallest=10&largest=10'); ?> 
                     </div>
                  <div id="footer">	
                  <ul>
<b>友情链接</b>：<?php get_links(2, '<li>', '</li>', '', TRUE, 'name', FALSE); ?>
                </ul>
</div>

		<div id="bottom">
			
			<div class="left">
			
				&copy; <?php echo mysql2date('Y',current_time('timestamp')); ?> <a href="<?php bloginfo('url'); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>.版权所有

			</div> <!--end .left--> 
			
			<div class="right">
				  theme by:<a href="http://www.vecorps.com" target="_blank">channel</a>|
<script src="http://s11.cnzz.com/stat.php?id=2078333&web_id=2078333" language="JavaScript"></script>
			</div> <!--end .right-->
				
			<div class="clear"></div>
		
		</div> <!--end #bottom -->
  
</div> <!--end #wrapper -->

<!--begin of body code-->	
<?php if(get_theme_mod('body_code_status') == "Yes") echo stripslashes(get_theme_mod('body_code')); ?>
<!--end of body code-->

<script type="text/javascript">
function mycarousel_initCallback(carousel)
{ 
};

jQuery(document).ready(function() {
    jQuery('#carousel').jcarousel({
		wrap: 'last',
        visible: 3,
        scroll: 1,
		wrap: 'circular',
        initCallback: mycarousel_initCallback
    });
});
</script>
 
<script type="text/javascript">
/* <![CDATA[ */

$(function() {
$(".tabs").tabs(".slide li", {event:'mouseover'});
 
  var scrollableElements = $(".scrollable li");
 if (scrollableElements.size() <= 4) {
  $("a.browse").addClass("disabled");
 }
 $(".scrollable").scrollable({
  "size": 4,
  "vertical":true
 });
 scrollableElements.click(function() {
  $("#panes .active").removeClass("active");
  $("#panes ." + $(this).attr("class").split(' ').slice(0, 1)).addClass("active");
 }).filter(":first").click();
});  
/* ]]> */

</script>

<?php wp_footer(); ?>

</body>
</html>