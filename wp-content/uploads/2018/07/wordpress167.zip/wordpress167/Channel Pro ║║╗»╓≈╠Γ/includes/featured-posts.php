    	<div id="featured"> 

		<div class="scrollabler">

                <div class="heading">
				<span class="heading-text"><?php _e('推荐文章', 'themejunkie'); ?></span>
			</div> <!-- end .heading -->	

 <?php $otherFeaturedPost = new WP_Query();$otherFeaturedPost->query('showposts=4&cat=8'); ?> 

  <?php while ($otherFeaturedPost->have_posts()) : $otherFeaturedPost->the_post(); ?> 

	<div class="slider">

					<?php
				$thumb = get_thumbnail($post->ID, get_theme_mod('thumb_key'),get_theme_mod('thumb_key'));
				$width = get_theme_mod('thumb_width');
				$height = get_theme_mod('thumb_height');
				$auto = get_theme_mod('thumb_auto');
										
				if($thumb) {	
					if($auto == 'Yes')
						$url = get_bloginfo('template_url').'/timthumb.php?src='.$thumb.'&amp;h='.$height.'&amp;w='.$width.'&amp;a=t&amp;zc=1';
					else
						$url = $thumb;
					
				} else {
					$url = get_bloginfo('template_url').'/images/default-thumb.gif';
				}
				
				echo '<a href="'.get_permalink().'" title="'.the_title_attribute( 'echo=0' ).'"><img width="180" height="120" src="'.$url.'" alt="'.get_the_title().'" /></a>';
			?>
 					<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>

				</div>

					 <?php $c++; endwhile; wp_reset_query(); ?> 	 

			</div>		 
<div id="theticker">

    <div id="m3ticker">

       <div id="tickimg">   <img src="<?php bloginfo('template_directory'); ?>/images/latestnews.png" alt="Hot News" />    </div>  

          <div id="ticker-area">      </div>

   <div id="cb"></div>

    </div>  <div class="navi"></div>  <div id="cb"></div>

    </div>    

    </div>    
