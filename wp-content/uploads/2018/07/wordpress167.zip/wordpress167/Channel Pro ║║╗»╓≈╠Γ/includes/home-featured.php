<div id="slider-wrapper" class="clear">

	<?php
		$container_height = 'height:'.(get_theme_mod('featured_thumb_height')+12).'px';
	?>
	
    <div id="slider" class="nivoSlider">
    
    		<?php 
			$sticky = get_option('sticky_posts'); 
			$home_featured_from = get_theme_mod('home_featured_from');
			$home_featured_num = get_theme_mod('home_featured_num');
			$home_featured_cat = get_theme_mod('home_featured_cat');
			
			if($home_featured_from == 'Sticky Posts') {
				query_posts(array(
					'showposts' => $home_featured_num,
					'post__in' => $sticky,
					'caller_get_posts' => 1 
				)); 
			} else {
				query_posts(array(
					'showposts' => $home_featured_num,
					'cat' => $home_featured_cat,
					'caller_get_posts' => 1 
				)); 
			}
			while(have_posts()) : the_post(); 
			global $wp_query; $maxnum = $wp_query->found_posts;
		 ?>
        
        	<?php
				$thumb = get_thumbnail($post->ID, get_theme_mod('featured_thumb_key'),get_theme_mod('featured_thumb_key'));
				$width = get_theme_mod('featured_thumb_width');
				$height = get_theme_mod('featured_thumb_height');
				$auto = get_theme_mod('featured_thumb_auto');
										
				if($thumb) {	
					if($auto == 'Yes')
						$url = get_bloginfo('template_url').'/timthumb.php?src='.$thumb.'&amp;h='.$height.'&amp;w='.$width.'&amp;a=t&amp;zc=1';
					else
						$url = $thumb;
									
					echo '<a class="featured-thumb" href="'.get_permalink().'" title="'.the_title_attribute( 'echo=0' ).'"><img width="'.$width.'" height="'.$height.'" src="'.$url.'" alt="'.get_the_title().'" title="'.get_the_title().'" /></a>';
				}
				?>
		 	<?php endwhile; wp_reset_query(); ?>
    </div>

    
</div>

<script type="text/javascript">
	 $(window).load(function() {
	 $('#slider').nivoSlider( {
	         controlNav:false, //1,2,3...
	 }
	 );
	 });
</script>