<?php 
/*
Template Name: 投稿
*/ 
get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="post" id="post-<?php the_ID(); ?>">

			<h2 class="post-title">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
			</h2>

			<img src="http://images.jandou.com/page/tougao.jpg" alt="" />
			<form id="tougaoform" method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			<p><input id="author" type="text" size="35" value="" name="tougao_authorname" /><label>昵称（*必填）</label></p>
			<p><input id="email" type="text" size="35" value="" name="tougao_authoremail" /><label>邮箱（*必填）</label></p>
			<p><input id="url" type="text" size="35" value="" name="tougao_authorblog" /><label>您的博客/文章来源</label></p>
			<p><input id="tougao_title" type="text" size="35" value="" name="tougao_title" /><label>文章标题（*必填）</label></p>
			<p><input id="tags" type="text" size="35" value="" name="tougao_tags" /><label>文章标签（多个标签请用英文逗号 , 分开）</label></p>
			<p><?php wp_dropdown_categories('show_option_none=请选择文章分类&show_count=1&hierarchical=1&hide_empty=0'); ?><label>文章分类（*必填）</label></p>
			<textarea rows="15" cols="55" id="tougao" name="tougao_content"></textarea>
			<p>
			<input type="hidden" value="send" name="tougao_form" />
			<input id="submit" type="submit" value="提交" />
			<input id="reset" type="reset" value="重填" />
			</p>
			</form>	 
		</div><!-- End of #content -->
<p><h4>说明:</h4>1. 在线投递功能供没有注册或不想登录后台的用户使用，不需要注册即可投递，简单快捷。<br> 2. 内容中有图片的，在文中用图片的地址代替，编辑会在整理时进行图片上传。如果是本地照片想要上传，建议还是登录后台进行投递。<a href="http://www.jandou.com/submit">详细帮助</a><br> 3. 内容中有链接的，在文中的相关位置注明链接地址即可，编辑会在整理时加上链接。<br> 4. 如果是转载，请尽量注明出处。</p>
	<?php endwhile; endif; ?>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>