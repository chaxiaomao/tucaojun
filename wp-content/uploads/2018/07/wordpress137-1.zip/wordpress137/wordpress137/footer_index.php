<div id="footer_ge_2"></div>
<iframe width="980" height="150" frameborder="0" scrolling="no" src="http://app.wumii.com/ext/widget/hot.htm?prefix=http%3A%2F%2Fwww.jandou.com%2F&num=8&t=2"></iframe>
<div id="footer_ge_2"></div>
 <!--底部版权信息-->
	 <div id="footer_bottom">
		<span id="rss">
			<a href="http://www.jandou.com/how-to-attention">订阅说明</a>
			<a href="http://feed.feedsky.com/jandou2" target="_blank">订阅文章</a>
		</span>
			<p id="footer_bottom_one">
<a href="http://www.jandou.com/ad">广告投放</a> | <a href="http://www.jandou.com/sponsor">赞助商家</a> | 友情推广：<a href="http://www.dvd-creator-converter.com/tutorials/remove-wmv-drm-protection-free.html" title="remove drm from wmv " target="_blank" >remove drm from wmv</a> | <a href="http://www.maituku.com/" target="_blank">卖图库</a>
			</p>
			<p style="margin: 2px 0;"><a href="http://www.jandou.com/friends.html" target="_blank">友情链接</a> | <a href="http://www.jandou.com/about">关于煎豆</a>  | <script src="http://s16.cnzz.com/stat.php?id=2368716&web_id=2368716" language="JavaScript"></script> | <a href="http://www.jandou.com/sitemap">站点地图</a>  <a href="http://www.jandou.com/sitemap_baidu.xml">.</a> <a href="http://www.jandou.com/sitemap.xml">.</a> <a href="http://www.jandou.com/sitemap.html">.</a> | ©2011 JANDOU - 版权归煎豆网所有 | <a>蜀ICP备06953128号</a> .</p>
		</div>
</div>
<!--//#最底部信息footer_bottom-->
<?php wp_footer(); ?>
</div>
</body>
</html>