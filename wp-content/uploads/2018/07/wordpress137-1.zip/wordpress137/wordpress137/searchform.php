<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<ul>
	<li><input type="text" value="<?php the_search_query(); ?>" name="s" id="s" /></li>
	<li><input type="submit" id="searchsubmit" value="Search" /></li>
</ul>
</form>
