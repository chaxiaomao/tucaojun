<?php get_header(); ?>

<div id="error" class="post">
	<h1>你所访问的页面不存在....</h1>
	<p>非常抱歉-错误404，没有找到您查询的页面或图片，请尝试在搜索框中搜索其他内容。</p>
	<p>&nbsp;&nbsp;&nbsp;&nbsp;这里我们有些建议要给您.</p>
	<ol>
		<li>查看地图：<span>您可以查看<a href="/sitemap">网站地图</a>进一步查找你需要的信息。</span></li>
		<li>联系站长：<span>如果您真的发现了什么错误,您能&nbsp;<a href="/contact">联系</a>&nbsp;并告之我们,那您真是太好了,非常感谢.</span></li>
	</ol>
</div>
<!--随机文章1-->
	<div class="sapce-half">
	<div class="entry-header">
	<div class="entry-name">为你推荐文章：</div>
	</div>
	<div class="random">
			<ul>
				<?php $rand_posts = get_posts('numberposts=8&orderby=rand');  foreach( $rand_posts as $post ) : ?>
				<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
				<?php endforeach; ?>
			</ul>
	</div>
	</div>
<!--随机文章2-->
	<div class="sapce-half">
	<div class="entry-header">
	<div class="entry-name"></div>
	</div>
	<div class="random">
			<ul>
				<?php $rand_posts = get_posts('numberposts=8&orderby=rand');  foreach( $rand_posts as $post ) : ?>
				<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
				<?php endforeach; ?>
			</ul>
	</div>
	</div>	
</div><!-- End of #content -->

<div id="sidebar_page">

<p style="width: 400px;height: 280px;text-align: right;margin-top: 18px;">
<script type="text/javascript"><!--
google_ad_client = "pub-0877316713681807";
/* 336x280, 创建于 11-8-18 */
google_ad_slot = "3084433754";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</p>

<p>
<!-- 搜索框 -->
<form style="margin-left: 64px;" method="get" id="search" action="http://www.jandou.com/">
<input style="width: 258px; padding: 3px 6px;border: 1px solid #ccc;font: 12px 'Microsoft Yahei';" type="text" name="s" value="输入关键字可以搜索你要的内容..." onblur="if(this.value=='') this.value='输入关键字可以搜索你要的内容...';" onfocus="if(this.value=='输入关键字可以搜索你要的内容...') this.value='';">
<input type="submit" value="Search+" id="searchsubmit">
</form>	
<!-- 关键字推荐 -->
</p>
<p>
	<li style="margin-left: 64px;">
		<strong>热门关键词</strong>：
		<a href="http://www.jandou.com/fresh-express/">新鲜速递</a> 
		<a href="http://www.jandou.com/smart-home/apple-fans">+苹果迷</a>
		<a href="http://www.jandou.com/tag/%e5%bb%ba%e7%ad%91">建筑</a> 
		<a href="http://www.jandou.com/tag/%E5%88%9B%E6%84%8F">+创意</a> 
		<a href="http://www.jandou.com/tag/%e8%ae%be%e8%ae%a1">设计</a> 
		<a href="http://www.jandou.com/tag/%e5%ae%b6%e5%b1%85">+家居</a> 
	</li>
</p>
</div><!-- End of #sidebar_page 改边栏为自定义边栏-->

<?php get_footer(); ?>