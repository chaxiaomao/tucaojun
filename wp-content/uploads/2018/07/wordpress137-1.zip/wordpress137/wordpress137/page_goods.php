<?php 
/*
Template Name: 无侧栏页面
*/ 
get_header(); ?>
		</div><!-- End of #content -->
	<div id="content_no_siderbar">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="post_no_siderbar" id="post-<?php the_ID(); ?>">

			<h2 class="post-title_no_siderbar">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
			</h2>

			<div class="post-entry_no_siderbar">
				<?php the_content(''); ?>
			</div>
		
		</div><!-- End of #content_no_siderbar-没有侧边栏的内容区 -->

		<!--//显示投票按钮	-->
		<?php //if (function_exists('emo_vote_display')) emo_vote_display('No votes', '1 vote', '% votes'); //这个函数是调用投票插件。并在文章页面显示投票?>
	<?php endwhile; endif; ?>

</div>

<?php include('footer_index.php'); ?>

