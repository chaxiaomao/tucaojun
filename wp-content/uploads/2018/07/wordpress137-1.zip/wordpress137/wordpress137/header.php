<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta name="keywords" content="煎豆,好货搜罗,iphone,小清新,唯美,智慧居家,周末创意专题,新鲜速递,创意设计,家居导购,windows8问题解决，建筑设计,创意摄影,创意家居,简约生活,室内装饰,发现新鲜,创意礼物,创意产品,生日礼物,挖掘美好" />
<meta name="description" content="煎豆网，关注居家生活以及创意设计的新锐网络媒体！" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="icon" href="http://www.jandou.com/favicon.ico" mce_href="http://www.jandou.com/favicon.ico" type="image/x-icon">
<title><?php wp_title(' | ', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<link rel="stylesheet" href="http://www.jandou.com/wp-content/themes/jandou_3/style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="http://www.jandou.com/wp-content/themes/jandou_3/sidebar.css" type="text/css" media="screen" />
<link rel="stylesheet" href="http://www.jandou.com/wp-content/themes/jandou_3/content.css" type="text/css" media="screen" />
<link rel="stylesheet" href="http://www.jandou.com/wp-content/themes/jandou_3/footer.css" type="text/css" media="screen" />
<link rel="stylesheet" href="http://www.jandou.com/wp-content/themes/jandou_3/404.css" type="text/css" media="screen" />
<link rel="stylesheet" href="http://www.jandou.com/wp-content/themes/jandou_3/page_goods.css" type="text/css" media="screen" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--暂时注释谷歌调用
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
-->
<script type="text/javascript" src="http://code.jquery.com/jquery-1.3.2.min.js"></script>
<script src="http://www.jandou.com/wp-content/themes/jandou_3/js/jscript.js" type=text/javascript></script>
<script type="text/javascript" src="http://www.jandou.com/wp-content/themes/jandou_3/js/ddsmoothmenu.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#imgshow li").hover(function(){//鼠标移动至图片显示解释文字
		$(".box",this).fadeIn(200).animate({opacity:0.9});
	},function(){
		$(".box",this).fadeOut(200);
	});
});

$(document).ready(function(){
	$("#back-to-top").hide();
		$(function () {
			$(window).scroll(function(){
				if ($(window).scrollTop()>100){
				$("#back-to-top").fadeIn(1500);
															}
				else
				{
					$("#back-to-top").fadeOut(1500);
				}
					});
	$("#back-to-top").click(function(){
		$('body,html').animate({scrollTop:0},1000);
				return false;
		});
	});
});
ddsmoothmenu.init({//这段JS是菜单滑动效果调用
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

ddsmoothmenu.init({
	mainmenuid: "smoothmenu2", //Menu DIV id
	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
	//customtheme: ["#804000", "#482400"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>

<body id="top">
<div id="wrapper">
<div id="header">
	<div class="top-nav" >
	  <div class="bd">
		<div id="top-nav-info">
			<a href="http://www.jandou.com/how-to-attention" title="更多订阅煎豆网的方式..."><img src="http://images.jandou.com/rss.gif"></a>
			<a target="_blank" href="http://www.jandou.com/wp-login.php?action=register"  title="注册豆友">注册</a>
			<a href="http://www.jandou.com/wp-admin/index.php"  title="登陆煎豆">登陆</a>
		</div>
		<div id="top-nav-items">
			<ul>         
				<li><a href="http://www.jandou.com/join-us"  title="欢迎加入我们">加入我们</a></li>
				<li><a href="http://www.jandou.com/contact" title="联系我们">联系</a></li>
				<li><a href="http://www.jandou.com/submit" title="分享你我，欢迎投稿">投稿</a></li>
				<li ><a href="http://www.jandou.com/douban-fm" title="打开即可收听豆瓣音乐">豆瓣FM</a></li>
				<li >为获得最佳浏览体验，建议使用<a href="http://www.google.com/chrome/" target="_blank" title="闪电般瞬间启动，网页加载速度堪称第一！">Chrome</a>浏览器.</li>		
			</ul>
		</div>
	  </div>
	</div>
	<div class="blog-title"><a href="<?php echo get_option('home'); ?>/"><img src="http://images.jandou.com/logo.jpg" alt="煎豆网，关注居家生活以及创意设计的新锐网络媒体！" title="快捷返回首页"></a></div>
	<div id="menuitem"><strong><a href="<?php echo get_option('home'); ?>/about" title="煎豆网，关注居家生活以及创意设计的新锐网络媒体！">煎豆网</a>「一个真正的创意，拥有它自己的力量与生命.」</strong></div>
	
	<div  id="smoothmenu1" class="ddsmoothmenu">
	<ul>
				<li><a href="http://www.jandou.com/">首页</a>
					<ul>
							<li><a href="http://www.jandou.com/join-us">ღ 加入我们</a></li>
						<li><a href="http://site.douban.com/120192/" target="_blank">ღ 豆瓣小站</a></li>
						<li><a href="http://weibo.com/jandou" target="_blank">ღ	新浪微博</a></li>
						<li><a href="http://t.qq.com/zhuziyi" target="_blank">ღ	腾讯微博</a></li>
					</ul>				
				</li>
				<!--11111111111111111111111111111-->
				<li><a href="<?php bloginfo('url'); ?>/fresh-express">新鲜速递</a>
					<ul>
						<li><a href="http://www.jandou.com/fresh-express/">+新鲜速递:分类文章</a></li>
						<li><a href="http://www.jandou.com/remen.html">+最新热门文章</a></li>
						<li><a href="http://www.jandou.com/fresh-express/weekend-topics">+周末创意专题</a></li>
						<li><a href="http://www.jandou.com/goods-collecting/taobao">+可以买到的创意</a></li>

					</ul>
				</li> 
				<!--4444444444444444444444444444-->
				<li><a href="<?php bloginfo('url'); ?>/design-art">设计艺术</a>
					<ul>
						<li><a href="http://www.jandou.com/designer-website.html">+设计师导航</a></li>
						<li><a href="<?php bloginfo('url'); ?>/design-art/architectural-design">+建筑设计</a></li>
						<li><a href="<?php bloginfo('url'); ?>/design-art/photography">+摄影随行</a></li>
						<li><a href="<?php bloginfo('url'); ?>/design-art/visual-communication/">+视觉传达 →</a>
							<ul>
							<li><a href="<?php bloginfo('url'); ?>/design-art/visual-communication/creative-ad">+创意广告</a></li>
							<li><a href="<?php bloginfo('url'); ?>/design-art/visual-communication/logo-app">+LOGO欣赏</a></li>
							<li><a href="<?php bloginfo('url'); ?>/design-art/visual-communication/brand">+品牌形象</a></li>
							</ul>
						</li>
						<li><a href="http://book.douban.com/subject_search?search_text=%E8%AE%BE%E8%AE%A1&cat=1001" target="_blank">+设计书籍</a></li>
					</ul>
				</li>
				<!--5555555555555555555555555555-->
				<li><a href="<?php bloginfo('url'); ?>/smart-home">智慧家居</a>
					<ul>
						<li><a href="http://www.jandou.com/smart-home/studio">+工作室</a></li>
						<li><a href="http://www.jandou.com/smart-home/kitchen">+厨房</a></li>						
						<li><a href="http://www.jandou.com/smart-home/interior-design">+室内设计</a></li>
						<li><a href="http://www.jandou.com/smart-home/furniture">+家具产品</a></li>
						<li><a href="http://www.jandou.com/smart-home/accessories">+家的装饰</a></li>
						<li><a href="http://www.jandou.com/smart-home/music-life">+音乐生活</a></li>
					</ul>
				</li>
	
				<!--66666666666666666666666666-->
				<li><a href="http://www.jandou.com/tech/">科技范儿</a>
					<ul>
						<li><a href="http://www.jandou.com/tech/apple-fans">+苹果迷</a></li>
						<li><a href="http://www.jandou.com/tech/windows8">+windows8</a></li>
					</ul>
</li>
				<li><a href="http://www.jandou.com/design-art/architectural-design">建筑设计</a></li>
								<!--2222222222222222222222222222222-->
				<li><a href="<?php bloginfo('url'); ?>/goods">好货搜罗</a>
					<ul>
						<li><a href="http://www.jandou.com/goods/dujia">+独家优惠</a></li>
						<li><a href="http://www.jandou.com/goods-collecting/collecting-season">+搜罗季专题</a></li>
						<li><a href="http://www.jandou.com/goods/home-life-club">+居家生活馆</a></li>
						<li><a href="http://www.jandou.com/tuijian">+店铺推荐整理</a></li>
						<li><a href="http://www.jandou.com/about-shop-rec">+关于店铺推荐</a></li>
						<!--
						<li><a href="#">+好店自荐</a></li>					
						<li><a href="#">+原创服饰</a></li>
						<li><a href="#">+手工DIY制品</a></li>
						<li><a href="#">+趣味礼物杂货</a></li>
						<li><a href="#">+浪漫婚礼用品ღღღ</a></li>
						<li><a href="#">+布艺蕾丝</a></li>
						<li><a href="#">+植物园艺</a></li>
						<li><a href="#">+正版精神粮食</a></li>
						-->
					</ul>
				</li>
				<!--3333333333333333333333333333-->
				<li><a href="#">店铺展示</a>
					<ul>
						<li><a href="http://www.jandou.com/goods/quality">+优质商铺NO.1</a></li>
						<li><a href="http://www.jandou.com/goods/cameraman">+优质摄影NO.1</a></li>
						<li><a href="http://www.jandou.com/goods/creative-gift">+创意礼物</a></li>
						<li><a href="http://www.jandou.com/goods/yuanchuang">+独立原创</a></li>

					</ul>
				</li>
		</ul>
	</div>
</div><!-- End of #header -->

<div id="main">
<div id="content">