<?php get_header(); ?>

	<?php if (have_posts()) : ?>
		
		<?php while (have_posts()) : the_post(); ?>

			<?php setPostViews(get_the_ID()); //这个函数负责文章的计数（首页）?>

				<div class="post" id="post-<?php the_ID(); ?>">
			
				<h2 class="post-title">
					<a href="<?php the_permalink() ?>" rel="bookmark" title="点击进入： <?php the_title(); ?>"><?php the_title(); ?></a>
				</h2>
								 
				<div class="post-entry">
					<?php the_content(); ?>
				</div>

				<p class="post-meta">
					<?php if (function_exists(the_tags)) { ?>
						<?php the_tags('标签: ', ', ') ?>
						&nbsp;｜&nbsp;浏览次数:<a href="<?php the_permalink(); ?>" title="共<?php  echo getPostViews(get_the_ID()); //这个函数负责文章计数显示?>次阅读">[<?php  echo getPostViews(get_the_ID()); //这个函数负责文章计数显示?>]</a>&nbsp;<!--暂时注释--&nbsp;评论:<?php //暂时注释comments_popup_link('[0]', '[1]', '[%]'); ?>--暂时注释--><br />
					<?php } ?>
					<?php _e('分类:'); the_category(', '); _e(' | '); edit_post_link('Edit', ''); ?>&nbsp;｜&nbsp;该文由&nbsp;<?php the_author_posts_link(); ?> 发布于:<?php the_time('Y-m-j') ?>
				</p>

			</div>

		<?php endwhile; ?>

	<!-- Navigation 分页导航-->
	 <div class="page_navi"><?php par_pagenavi(7); //调用木木的分页函数?></div>
	<!-- /Navigation -->
	<?php else : ?> 

		<div class="post"><p><?php _e('Sorry, but you are looking for something that isn\'t here.'); ?></p></div>

	<?php endif; ?>

	</div><!-- End of #content -->

<?php get_sidebar(); ?>
<?php include('footer_index.php'); ?>