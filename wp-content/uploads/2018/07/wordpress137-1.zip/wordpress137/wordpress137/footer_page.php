/**/
<div class="content-bg-bottom"></div>
<div id="footer_ge_2"></div>
<!--底部长幅广告
<div id="footer_ge_1"><a href="http://www.freedesign.cn/" target="_blank"><img src="http://pic.yupoo.com/zhuziyi_v/BbjLFr3n/6gbnp.jpg" /></a></div>
-->
<div id="footer"  class="layout">
    <div id="footer-c">
        <!--左底部开始 -->
		<div class="widget-footer-title">关键词</div>
        <ul class="widget-footer-content">
			<li><strong>站长推荐</strong>：
			<a href="http://www.jandou.com/contribute" title="网友在线投稿，欢迎您的推荐">网友投稿</a> 
			<a href="http://www.jandou.com/smart-home/music-life" title="心旷神怡+安静=音乐">淘音乐馆</a> 
			<a href="http://www.jandou.com/tag/workhouse" title="一些创意有趣的工作室">工作室</a> 
			<a href="http://www.jandou.com/goods" title="可以买得到的好货">良品推荐</a> 
			<a href="http://www.jandou.com/fresh-express">新鲜水果</a> 
			<a href="http://www.jandou.com/smart-home" title="温馨家居标杆推荐">家居馆</a> 
			<a href="http://www.jandou.com/goods" title="拒绝广告，仅此分享生活">好货搜罗</a> 
			</li>
			<li><strong>热门标签</strong>：
			<a href="http://www.jandou.com/tag/fresh">新鲜</a> 
			<a href="http://www.jandou.com/tag/%e5%bb%ba%e7%ad%91">建筑</a> 
			<a href="http://www.jandou.com/tag/%E5%88%9B%E6%84%8F">创意</a> 
			<a href="http://www.jandou.com/tag/%e8%ae%be%e8%ae%a1">设计</a> 
			<a href="http://www.jandou.com/tag/%e5%ae%b6%e5%b1%85">家居</a> 
			<a href="http://www.jandou.com/tag/iphone" title="iphone">IPhone</a>
			<a href="http://www.jandou.com/tag/%e5%8e%a8%e6%88%bf">厨房</a>
			<a href="http://www.jandou.com/tag/%e5%b0%8f%e6%b8%85%e6%96%b0">小清新</a>
			<a href="http://www.jandou.com/tag/fresh">新鲜</a>
			<a href="http://www.jandou.com/tag/%e6%9c%89%e8%b6%a3">有趣</a>
			<a href="http://www.jandou.com/tag/%e7%ae%80%e7%ba%a6">简约</a>
			</li>
       	</ul>
		<div class="widget-footer-title">关注订阅</div>
        <ul class="widget-footer-content">
          <li>订阅到 <a href="http://fusion.google.com/add?feedurl=http://www.jandou.com/feed">google reader</a>｜
		  <a href="http://9.douban.com/reader/subscribe?url=http://www.jandou.com/feed"> 豆瓣九点</a>
		  </li>
          <li>订阅到 <a href="http://mail.qq.com/cgi-bin/feed?u=http://www.jandou.com/feed">QQ阅读</a>｜
		  <a href="http://www.xianguo.com/subscribe.php?url=http://www.jandou.com/feed">鲜果</a>｜
		  <a href="http://www.zhuaxia.com/add_channel.php?url=http://www.jandou.com/feed">抓虾</a>｜
		  <a href="http://inezha.com/add?url=http://www.jandou.com/feed">哪吒</a>｜
		  <a href="http://reader.youdao.com/b.do?keyfrom=bookmarklet&amp;url=http://www.jandou.com/feed">有道</a>
		  </li>
          <li><a href="http://t.sina.com.cn/invite/att_reqback.php?code=tpJokNh" target="_blank">新浪微博</a> ｜
          <a href="http://www.douban.com/group/jandou/"  target="_blank">豆瓣创意小组</a> ｜
          <a href="http://www.douban.com/group/db-site/" target="_blank"><strong>豆瓣小站精选</strong></a></li>
       </ul>
 </div>
<!--左底部结束 -->
 
<!--中底部开始 -->
<div id="footer-l"> 
		<a href="http://www.jandou.com/fresh-express" target="_blank;">
		<img src="http://images.jandou.com/ad/ad_r2/good_life.jpg" width="140" title="新鲜资讯！" >
		</a>
</div>
<!--中底部结束 -->

<!--右底部开始 -->
    <div id="footer-r">
	<div class="widget-footer-title">优秀设计链接（内）</div>
        <ul class="widget-footer-content">
	 <li>
		<a href="http://www.fostyle.net" target="_blank">佛味文革/创意控</a> | 
		<a href="http://www.wantfeel.com/" target="_blank">WantFeel</a>
	 </li>
	<li>
		<a href="http://www.designerscn.com/" target="_blank">中国设计师博客</a>｜
		<a href="http://cloud.dodoo.cc" target="_blank">云朵工厂</a>
	</li>
	<li>
		<a href="http://www.wepost.net/" target="_blank">每日星球报</a> |
		<a href="http://wuhoucy.com/" target="_blank">午后创意</a> |
		<a href="http://gkoo.net/" target="_blank">极库</a>
	</li>
	<li>
		<a href="http://www.bloglee.net/" target="_blank">苦香阁</a> |	
		<a href="http://www.mb-wx.com/" target="_blank">木本无心</a> |  
		<a href="http://www.closhow.cn/" target="_blank">简约生活</a>
	</li>
	<li>
		<a href="http://www.toodaylab.com/" target="_blank">理想生活实验室</a> | 
		<a href="http://asia-bookstore.com/" target="_blank">亚洲设计书店</a>
	</li>
	<li>
		<a href="http://www.rboke.com/" target="_blank">锐播客</a>
	</li>
  </div>
<!--右底部结束 -->
<div id="footer-l"> 
	<div class="widget-footer-title">友情链接</div>
        <ul class="widget-footer-content">

      	</ul>
</div>
<div id="footer_ge_2"></div>

 	 <div id="footer_bottom">
		<span id="rss">
			<a href="http://www.jandou.com/how-to-attention">订阅说明</a>
			<a href="http://feed.feedsky.com/jandou2" target="_blank">订阅文章</a>
		</span>
			<p id="footer_bottom_one">
<a href="http://www.jandou.com/ad">广告投放</a> | <a href="http://www.jandou.com/about">关于煎豆</a> |  <a href="http://www.jandou.com/contact">联系我们</a> | <a href="http://www.jandou.com/sitemap">站点地图</a>  <a href="http://www.jandou.com/sitemap_baidu.xml">.</a> <a href="http://www.jandou.com/sitemap.xml">.</a> <a href="http://www.jandou.com/sitemap.html">.</a>
			</p>
			<p style="margin: 2px 0;"><a href="http://www.jandou.com/friends.html" target="_blank">友情链接</a> |  <a href="http://www.jandou.com/sponsor">赞助商家</a> | <script src="http://s16.cnzz.com/stat.php?id=2368716&web_id=2368716" language="JavaScript"></script> | ©2011 JANDOU - 版权归煎豆网所有 | <a>蜀ICP备06953128号</a> .</p>
		</div>
 </div>
 <!--//#最底部信息footer_bottom-->
<?php wp_footer(); ?>
</div>
</body>
</html>