<?php get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="post" id="post-<?php the_ID(); ?>">

			<h2 class="post-title">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
			</h2>

			<div class="post-entry">
				<?php the_content(''); ?>
			</div>
		</div><!-- End of #content -->
		<!--//显示投票按钮	-->
		<?php if (function_exists('emo_vote_display')) emo_vote_display('No votes', '1 vote', '% votes'); //这个函数是调用投票插件。并在文章页面显示投票?>
	<?php comments_template(); ?>

	<?php endwhile; endif; ?>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
