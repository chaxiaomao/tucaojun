<div id="sidebar">
	<ul id="sb2">
	<!-- 边栏静态-->
		<li id="sb2_pic">
			<a href="https://www.google.com/reader/view/feed/http://www.jandou.com/feed?source=ignition" title="推荐您订阅我们到谷歌阅读（google reader），以更快捷地获取更多生活信息。" target="_blan"><img src="http://images.jandou.com/rss_big.gif" width="140" target="_blank" ></a> 
			<!--注释杂良集   <script src="http://i2.okjee.com/js/union_jandou.js"></script>    -->
			<a href="http://site.douban.com/slpr/" target="_blank"><img src="http://images.jandou.com/ad/ad_r2/slpr.jpg"  width="140" title="夜未眠·豆小站"></a>
			<a href="http://www.fun-creative.com/ring.html" target="_blank"><img src="http://images.jandou.com/ad/ad_r2/fun-creative.jpg"  width="140" title="乐创科技·创意产品"></a>
			<a href="http://www.jandou.com/fresh-express" target="_blank;"><img src="http://images.jandou.com/ad/ad_r2/good_life.jpg" width="140" title="新鲜资讯！"></a>
			<a href="http://item.taobao.com/item.htm?id=12366895011" target="_blank"><img src="http://images.jandou.com/ad/ad_r2/since1984.jpg"  width="140" title="心动项链"></a>
			<a href="http://www.jandou.com/douban-fm" target="_blank"><img src="http://images.jandou.com/ad/ad_r2/dbfm.jpg"  width="140" title="与你的音乐不期而遇"></a>
		</li>
	<!--边栏动态判断-->
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(2) ) : ?>
		<?php endif; // End Sidebar Widgets 2 ?>
	</ul>
	<ul id="sb1">
		<li id="miaosu" > 
			<h2 class="widgettitle" style="text-align: center">煎豆网，创意生活每一天！</h2>
			<p>关注居家生活创意设计的新锐网络媒体！</p> 
			<p style="text-align: center">
				<a href="http://www.jandou.com/about" target="_parent"><strong>关于</strong></a>| 
				<a href="http://www.jandou.com/contact" target="_parent"><strong>联系</strong></a>| 
				<a href="http://www.jandou.com/submit" target="_parent"><strong>投稿</strong></a>| 
				<a href="http://www.jandou.com/about-shop-rec" target="_parent"><strong>自荐</strong></a>| 
				<a href="http://feed.feedsky.com/jandou2" target="_blank"><strong>RSS</strong></a>
			</p> 
		</li>
		<li style="text-align: center;border: 0;">
<embed height="150" width="200" flashvars="bannerWidth=200&bannerHeight=150&bannerSID=http://img.uu1001.cn/x3/2011-11-05/20-59/2011-11-05_13e6e06f9dd9f502c86b83a31634e0e9_4.xml&bannerXML=&bannerLink=http%3A%2F%2F&dataSource=&bid=26295577&appSource=default" wmode="transparent" allowscriptaccess="always" quality="high" name="26295577" id="26295577" style="" src="http://img.uu1001.cn/bcv3.swf?v=20111012" type="application/x-shockwave-flash"/></embed>
		</li>
		<li>
			<h2><?php _e('最新文章'); ?></h2>
				<ul>
					<?php
					global $post; $myposts = get_posts('numberposts=8');
					foreach($myposts as $post) : setup_postdata($post);
					?>
				<li>
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</li>
				<?php endforeach; ?>
				</ul>
		</li>
<li id="google_ad_sidebar_2" style="padding: 0 10px;">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0877316713681807";
/* 200&#42;200图片广告 */
google_ad_slot = "3916268228";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</li>
			<h2>随机文章</h2>
		<ul>
			<?php $rand_posts = get_posts('numberposts=8&orderby=rand');  foreach( $rand_posts as $post ) : ?>
				<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
			<?php endforeach; ?>
		</ul>
<li id="touming_pic" align="center"><a href="http://www.wmpic.me/"  target="_blank"><img src="http://www.wmpic.me/wp-content/themes/wmpic/images/logo.png"  style="width: 220px;height: 32px;" alt="唯美图片" /></a></li>
<li id="touming_pic" align="center"><a href="http://www.wuyun.in/"  target="_blank"><img src="http://www.wuyun.in/logo.png"  style="width: 220px;height: 78px;"  alt="乌云壁纸" /></a></li>

		<!--边栏动态判断-->
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : ?>
		<!-- Latest Posts -->
		<?php endif; // End Sidebar Widgets 1 ?>
		</ul>


	</div><!-- End of #sidebar -->