<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');
		
	if (!empty($post->post_password)) { // if there's a password
		if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
			?>
			<p class="nocomments"><?php _e('This post is password protected. Enter the password to view comments.'); ?></p>
			<?php
			return;
		}
	}
	/* This variable is for alternating comment background */
	$oddcomment = 'class="alt" ';
?>

<!-- You can start editing here. -->
<div id="cmts">
<?php if ($comments) : ?>
	<h2 id="comments"><?php comments_number('No Comments', '1 Comment', '% Comments' );?></h2>

	<ol class="cmt-list">

	<?php foreach ($comments as $comment) : ?>

		<li <?php echo $oddcomment; ?>id="comment-<?php comment_ID() ?>">
		<p class="cmt-meta">
			<?php comment_author_link() ?><?php if ($comment->comment_approved == '0') : ?><em><?php _e('(Your comment is awaiting moderation.)'); ?></em>
			<?php endif; ?><?php edit_comment_link('Edit',' | ',' | '); ?>
			<a href="#comment-<?php comment_ID() ?>" title=""><?php comment_date('Y-m-j'); _e(', '); comment_time(); ?></a>
 
		</p>
		<div class="cmt-text">
			<?php comment_text() ?>
		</div>
		</li>

	<?php
		/* Changes every other comment to a different class */
		$oddcomment = ( empty( $oddcomment ) ) ? 'class="alt" ' : '';
	?>

	<?php endforeach; /* end for each comment */ ?>

	</ol>

 <?php else : // this is displayed if there are no comments so far ?>

	<?php if ('open' == $post->comment_status) : ?>
		<!-- If comments are open, but there are no comments. -->

	 <?php else : // comments are closed ?>
		<!-- If comments are closed. -->
		<p class="nocomments"><?php _e('Comments are closed.'); ?></p>

	<?php endif; ?>
<?php endif; ?>


<?php if ('open' == $post->comment_status) : ?>
	<!-- 评论 分页导航-->
<div id="comments-nav"><?php paginate_comments_links('prev_text=上一页&next_text=下一页');?></div>
	<!-- 评论 分页导航-->
<h2 id="addcomment"><?php _e('赶快写下你的想法，或者此刻的灵感吧！'); ?></h2>

<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p>
	<?php _e('You must be '); ?><a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>"><?php _e('logged in'); ?></a><?php _e(' to post a comment.'); ?>
</p>
<?php else : ?>

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">

<?php if ( $user_ID ) : ?>

<p>
	<?php global $current_user;get_currentuserinfo();echo get_avatar( $current_user->user_email, 35); //显示头像?>
	<?php _e('当前登录用户:'); ?><a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a><?php _e(' | '); ?><a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="注销 »"><?php _e('注销 » '); ?></a>
</p>

<?php else : ?>

<p>
	<label for="author"><?php _e('Name'); ?><?php if ($req) echo " (必需的)"; ?></label><br/>
	<input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="" tabindex="1" />
</p>

<p>
	<label for="email"><?php _e('E-mail'); ?><?php if ($req) echo " (必需的)"; ?></label><br/>
	<input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="" tabindex="2" />
</p>

<p>
	<label for="url"><?php _e('Website'); ?></label><br/>
	<input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="" tabindex="3" />
</p>

<?php endif; ?>

<p>
	<label for="url"><?php _e('Comment'); ?></label><br/>
	<textarea name="comment" id="comment" cols="" rows="" tabindex="4" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"></textarea>
</p>
<?php endif; ?>
<?php include(TEMPLATEPATH . '/smiley.php'); ?>
<p>
	<input name="submit" type="submit" id="submit" tabindex="5" value="<?php _e('确认/CTRL+ENTER', 'kubrick'); ?>" /><!--评论提交按钮-->
	<?php comment_id_fields(); ?> 
	<input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
</p>
 	<?php comment_id_fields(); ?> 
	<?php do_action('comment_form', $post->ID); ?>
</form>

<?php endif; ?>
</div>
