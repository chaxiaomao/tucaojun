<?php get_header(); ?>

	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>

			<div class="post" id="post-<?php the_ID(); ?>">
			
				<h2 class="post-title">
					<a href="<?php the_permalink() ?>" rel="bookmark" title="点击进入： <?php the_title(); ?>"><?php the_title(); ?></a>
				</h2>
								 
				<div class="post-entry">
					<?php the_content(); ?>
				</div>

				<p class="post-meta">
					<?php if (function_exists(the_tags)) { ?>
						<?php the_tags('标签: ', ', ') ?>
						&nbsp;｜&nbsp;PV:<a href="<?php the_permalink(); ?>" title="共<?php  echo getPostViews(get_the_ID()); //这个函数负责文章计数显示?>次阅读">[<?php  echo getPostViews(get_the_ID()); //这个函数负责文章计数显示?>]</a>&nbsp;｜&nbsp;评论:<?php comments_popup_link('[0]', '[1]', '[%]'); ?><br/>
					<?php } ?>
					<?php _e('分类:'); the_category(', '); _e(' | '); edit_post_link('Edit', ''); ?>&nbsp;｜&nbsp;该文由&nbsp;<?php the_author_posts_link(); ?> 发布于:<?php the_time('Y-m-j') ?>
				</p>

			</div>

		<?php endwhile; ?>
<!--
		<div class="pagenavi">
			<?php if(function_exists('wp_pagenavi')) : ?>
				<?php wp_pagenavi(); ?>
			<?php else : ?>
				<div class="alignleft"><?php next_posts_link('&laquo; Older Posts') ?></div>
				<div class="alignright"><?php previous_posts_link('Newer Posts &raquo;') ?></div>
			<?php endif; ?>
		</div>
-->


	<!-- Navigation 分页导航-->
	 <div class="page_navi"><?php par_pagenavi(7); //调用木木的分页函数?></div>
	 <!-- /Navigation -->
		
	<?php else : ?> 

		<div class="post"><p><?php _e('嘿嘿，这儿还没文章出生呢...不过你可以玩玩下边这个有趣的在线涂鸦.'); ?></p>
<p><object style="width: 580px; height: 400px;" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="500" height="320" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0"><param name="src" value="https://wbx-files.s3.amazonaws.com/jacksonpollock_by_miltos_manetas.swf"><embed style="width: 580px; height: 400px;" type="application/x-shockwave-flash" width="500" height="320" src="https://wbx-files.s3.amazonaws.com/jacksonpollock_by_miltos_manetas.swf"></object></p>
		</div>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
