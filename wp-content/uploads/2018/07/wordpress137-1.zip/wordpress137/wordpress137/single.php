<?php get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="post" id="post-<?php the_ID(); ?>">
			
				<?php  setPostViews(get_the_ID()); //这个函数负责文章的计数?>
			
					<h2 class="post-title" >
						<a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
					</h2>
				<div class="post-entry">
					<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
					<?php wp_link_pages(array('before' => '<div class="fenye">分页阅读：', 'after' => '','next_or_number' => 'next', 'previouspagelink' => '上一页', 'nextpagelink' => "")); ?>
					<?php wp_link_pages(array('before' => '', 'after' => '', 'next_or_number' => 'number','link_before' =>'<span>', 'link_after'=>'</span>')); ?>  
					<?php wp_link_pages(array('before' => '', 'after' => '</div>','next_or_number' => 'next', 'previouspagelink' => '', 'nextpagelink' => "下一页")); ?>
				</div>

				<div id="post-other">		
					<!--文章底部推广区-->
					<div style="height:90px; width:558px; margin: 0 auto;padding:10px 0px; clear:both;"><a href="http://cnrdn.com/mXV4" target="_blank"><img src="http://www.ideacool.cn/ad/jiandou_558x90.jpg" /></a></div>
						<!--订阅按钮开始-->
						<div id="single-sub">
					<div class="pick">
						订阅到
						<a href="https://www.google.com/reader/view/feed/http://www.jandou.com/feed?source=ignition" target="_blank" title="Google Reader">谷歌阅读</a> | 
						<a href="http://mail.qq.com/cgi-bin/feed?u=www.jandou.com/feed" target="_blank"title="订阅到QQ邮箱">QQ邮箱</a> | 
						<a href="http://9.douban.com/reader/subscribe?url=http://www.jandou.com/feed"target="_blank" title="订阅到豆瓣9点">豆瓣九点</a> | 
						<a href="http://www.xianguo.com/subscribe.php?url=http://www.jandou.com/feed" target="_blank" title="订阅到鲜果">鲜果</a> ，
收藏到
						<a href="javascript:window.open('http://bookmark.qq.com/post?title='+encodeURIComponent(document.title)+'&uri='+encodeURIComponent(document.location.href)+'&jumpback=2&noui=1','favit','width=930,height=470,left=50,top=50,toolbar=no,menubar=no,location=no,scrollbars=yes,status=yes,resizable=yes');void(0)">QQ书签</a> | 
						<a onclick="window.open('http://www.delicious.com/save?v=5&amp;noui&amp;jump=close&amp;url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title), 'delicious','toolbar=no,width=550,height=550'); return false;" href="http://www.delicious.com/save">del.icio.us</a> | 
						<a href="javascript:location.href='http://www.google.com/bookmarks/mark?op=add& bkmk='+encodeURIComponent(location.href)+'&title='+encodeURIComponent (document.title)" target="_blank">Google</a> | 
<a href="http://shuqian.youdao.com/manage?a=popwindow&title=<?php the_title(''); ?>&url=<?php the_permalink(); ?>" target="_blank">有道</a> 
					</div>
				</div>
<!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<span class="jiathis_txt">分享：</span>
	<a class="jiathis_button_qzone">QQ空间</a>
	<a class="jiathis_button_tsina">新浪微博</a>
	<a class="jiathis_button_renren">人人网</a>
	<a class="jiathis_button_kaixin001">开心网</a>
	<a class="jiathis_button_xiaoyou">朋友网</a>
	<a class="jiathis_button_qq">QQ收藏</a>
	<a href="http://www.jiathis.com/share?uid=96865" class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank">更多</a>
	<a class="jiathis_counter_style"></a>
</div>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=96865" charset="utf-8"></script>
<!-- JiaThis Button END -->
<!--
<?php if (function_exists('emo_vote_display')) emo_vote_display('No votes', '1 vote', '% votes'); //这个函数是调用投票插件。并在文章页面显示投票?>
-->
						<!--无觅网按钮开始-->
						<div id="wumiiDisplayDiv"></div>
						<!--//显示标签+分类+Edit（管理员）+引用通告+评论 RSS+增添想法-->
						<p class="post-meta">
							作者:<?php the_author_posts_link(); ?>&nbsp;|&nbsp;<?php edit_post_link('Edit', '', ' | '); ?>发布日期:<?php the_time('Y-m-j h:m') ?>&nbsp;|&nbsp;阅读次数:<?php  echo getPostViews(get_the_ID()); //这个函数负责文章计数显示?><?php _e(' | '); _e('分类:'); the_category(', '); ?><br />
							<?php if (function_exists(the_tags)) { ?>
								<?php the_tags('标签: ', ', ', '&nbsp;&nbsp;') ?>
							<?php } ?><br />
							<?php if ( pings_open() ) : ?><?php endif; ?>
							<?php next_post_link('上一篇: %link') ?>&nbsp;｜&nbsp;
							<?php previous_post_link('下一篇: %link') ?>
						</p>
				</div>
<div id="google_ad_post_bottom" style="padding: 0 54px 5px 54px;width: 468px;height: 60px;">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0877316713681807";
/* 文章底部图片468&#42;60 */
google_ad_slot = "6870834373";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>		
			</div><!-- End of #content -->

	<?php comments_template(); ?>

	<?php endwhile; else: ?>

		<div class="post"><p><?php _e('嘿嘿，这儿还没文章出生呢...不过你可以玩玩下边这个有趣的在线涂鸦.'); ?></p>
<p><object style="width: 500px; height: 320px;" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="500" height="320" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0"><param name="src" value="https://wbx-files.s3.amazonaws.com/jacksonpollock_by_miltos_manetas.swf"><embed style="width: 500px; height: 320px;" type="application/x-shockwave-flash" width="500" height="320" src="https://wbx-files.s3.amazonaws.com/jacksonpollock_by_miltos_manetas.swf"></object></p>
		</div>

<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
