<?php 

   /* 

   Template Name: 站点地图

   */ 
  ?>
<?php get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>		
	
			<p><strong><a href="<?php bloginfo('url'); ?>" alt="<?php bloginfo('name'); ?>">返回首页</a>>><a href="<?php bloginfo('url'); ?>/Sitemap" alt="Sitemap">Sitemap</a></strong></p>

			<div class="entry-header">
			<div class="entry-name">所有的文章:</div>
			</div>
			<ul>
				<?php $archive_query = new WP_Query('showposts=1000');
					while ($archive_query->have_posts()) : $archive_query->the_post(); ?>
				<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a> <?php comments_number('[0]', '[1]', '[%]'); ?></li>
				<?php endwhile; ?>
			</ul>
			
			<div class="sapce-4">
			<div class="entry-header">
			<div class="entry-name">按月分类:</div>
			</div>
			<div class="random-2">
					<ul>
							<?php wp_get_archives('type=monthly'); ?>
					</ul>
			</div>
			</div>			

			<div class="sapce-4">
			<div class="entry-header">
			<div class="entry-name">文章分类:</div>
			</div>
			<div class="random-2">
					<ul>
							<?php wp_list_categories('title_li=0'); ?>
					</ul>
			</div>
			</div>						
			
			<div class="sapce-4">
			<div class="entry-header">
			<div class="entry-name">RSS分类目录:</div>
			</div>
			<div class="random-2">
				<ul>
					<li><a href="<?php bloginfo('rdf_url'); ?>" alt="RDF/RSS 1.0 feed"><acronym title="Resource Description Framework">RDF</acronym>/<acronym title="Really Simple Syndication">RSS</acronym> 1.0 feed</a></li>
					<li><a href="<?php bloginfo('rss_url'); ?>" alt="RSS 0.92 feed"><acronym title="Really Simple Syndication">RSS</acronym> 0.92 feed</a></li>
					<li><a href="<?php bloginfo('rss2_url'); ?>" alt="RSS 2.0 feed"><acronym title="Really Simple Syndication">RSS</acronym> 2.0 feed</a></li>
					<li><a href="<?php bloginfo('atom_url'); ?>" alt="Atom feed">Atom feed</a></li>
				</ul>
			</div>
			</div>	
			
			<div class="clear rule"></div>
			
	<?php endwhile; endif; ?>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
