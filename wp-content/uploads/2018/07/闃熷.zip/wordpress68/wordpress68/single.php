<?php get_header(); ?>

<div id="content">
<div id="articles">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
 <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div id="article">

<div class="article-title"><a class="h1" href="<?php esc_url( the_permalink() ); ?>"><?php the_title(); ?></a></br>
<div class="article-meta"><img alt="作者" class="meta" src="<?php echo get_template_directory_uri() . '/icons/user.png'; ?>" width="10" height="12">&nbsp;&nbsp;<?php the_author(); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img alt="发表日期" class="meta" src="<?php echo get_template_directory_uri() . '/icons/calendar.png'; ?>" width="12" height="12"> &nbsp;&nbsp;<?php convention_get_date(); ?></div></div>

<div id="article-p"><?php if ( has_post_thumbnail() ) { ?><div class="post-thumbnail"><?php the_post_thumbnail(); ?></div><?php } ?>

<?php the_content(); ?>
<p>除非注明，文章均为<a href="http://www.19491013.com/" title="队室">队室</a>原创，欢迎转载！转载请注明本文地址，谢谢。</p>
<p>本文地址：<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a></p></div>
<div class="clear"></div>
<div class="ad_tao"><!-- 广告位：队室文章页面底部336*280 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("499521");</script></div>
<div class="tag-links"><?php the_tags('<div class="tags-title">关键词，点击可看相关文章：</div>', '', ''); ?></div><div class="clear"></div>
<div id="postnavi" class="block">
<div class="meiwen_post_title"><?php next_post_link('<span class="prev"><span class="arrow_left"></span>%link</span>') ?>
<?php previous_post_link('<span class="next"><span class="arrow_right"></span>%link</span>') ?></div>
</div>
<div class="clear"></div>
<div class="Related"><h3>要不，再看看下面的文章！</h3>
   <ul id="cat_related">
<?php
$cats = wp_get_post_categories($post->ID);
if ($cats) {

$cat = get_category( $cats[0] );
$first_cat = $cat->cat_ID;
$args = array(
        'category__in' => array($first_cat),
        'post__not_in' => array($post->ID),
        'showposts' => 6,
        'caller_get_posts' => 1
    );
query_posts($args);

if (have_posts()) :
    while (have_posts()) : the_post(); update_post_caches($posts); ?>
<li>* <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
<?php endwhile; else : ?>
<li>* 暂无相关文章</li>
<?php endif; wp_reset_query(); } ?>
</ul>
</div>
<div class="page-links"><?php wp_link_pages('before=<div class="page-title">PAGES</div>'); ?></div>
    
     <div class="category-links"><div class="tags-title"><?php _e( '所属栏目', 'convention' ); ?></div><?php the_category(''); ?></div>
<div class="clear"></div>
<?php edit_post_link( __( 'Edit', 'convention' ), '<div id="edit-link"><span class="edit-link">', '</span></div>' ); ?>

</div></div>
<?php endwhile; ?> 

<?php endif; ?>

<?php if ( comments_open() ) : ?>
<div id="comments">
<?php comments_template(); ?>
</div> 
<?php endif; ?>

</div>

<div id="sidebars">

<div id="sidebar">
	<?php get_sidebar(); ?>
</div>

</div>

<div class="clear"></div>

</div>


<?php get_footer(); ?>

<script type="text/javascript">
document.body.oncopy=function(){
 event.returnValue=false;
 var t=document.selection.createRange().text;
 var s="本文来源于：队室[http://www.19491013.com], 原文地址： <?php the_permalink() ?> ";
 clipboardData.setData('Text','\r\n'+t+'\r\n'+s+'\r\n');
}
</script>