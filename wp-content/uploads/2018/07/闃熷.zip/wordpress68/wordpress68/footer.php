</div></div></div></div></div></div>
<script type="text/javascript" src="/wp-content/themes/convention/jquery.js"></script>
<script type="text/javascript" src="/wp-content/themes/convention/Htwo.js"></script>
<?php if ( is_home() ||is_archive()): ?>
<div id="shangxia">
<div id="shang" title="↑ 返回顶部"></div>
<div id="xia" title="↓ 移至底部"></div>
</div>
<?php else:?>
<div id="shangxia">
<div id="shang" title="↑ 返回顶部"></div>
<div id="comt" title="查看评论"></div><div id="xia" title="↓ 移至底部"></div>
</div>
<?php endif; ?>
<?php wp_footer(); ?>
<div class="clear">
<!--cnzz tui-->
<script  type="text/javascript" charset="utf-8"  src="http://tui.cnzz.net/cs.php?id=1000002774"></script>
<!--cnzz tui--></div>
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&amp;img=5&amp;uid=14227" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
<div id="footer">Copyright © 2012-2015 队室. Powered by <a href="http://www.wordpress.org/" rel="external nofollow">WordPress</a>. Theme by <a href="http://fimply.com/" rel="external nofollow">convention</a>. <a href="http://www.19491013.com/sitemap.html" rel="external">网站地图</a>. <a href="http://www.19491013.com/sitemap_baidu.xml" rel="external">百度地图</a>. <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fe4059b549092701fbf34a312bc5e0485' type='text/javascript'%3E%3C/script%3E"));
</script>.</div>
</body>
</html>