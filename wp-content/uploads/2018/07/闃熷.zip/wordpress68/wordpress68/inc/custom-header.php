<?php

$convention_headeroptions = array(
    'header-text'   => false,
    'random-default' => false,
	'uploads'       => true,
	'height'        => 300,
    'width'         => 1080,
);
add_theme_support( 'custom-header', $convention_headeroptions );

        
?>