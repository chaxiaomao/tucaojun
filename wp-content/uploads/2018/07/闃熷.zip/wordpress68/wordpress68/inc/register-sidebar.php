<?php

register_sidebar(array(
'name' => __('Sidebar', 'convention'),
'before_widget' => '',
'after_widget' => '',
'before_title' => '<div id="sidebar-widget"><div class="sidebar-heading">',
'after_title' => '</div></p>',
));

?>