<?php get_header(); ?>

<div id="content">
<div id="articles">
<?php if ( is_category()  ) : ?>
		        	<div class="post-bt"><h2><?php echo single_cat_title( null, false ); ?></h2>
					<?php $category_description = category_description();
		                if ( ! empty( $category_description ) )
		                    printf("<p>%s</p>", $category_description); ?>					
		        	</div>
<?php endif; ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
 <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div id="article">

<?php if ( is_sticky() ) : ?><div class="post-title"><?php _e( 'Featured', 'convention' ); ?></div><?php endif; ?>
<div class="article-title"><a class="h1" href="<?php esc_url( the_permalink() ); ?>"><?php the_title(); ?></a></br>
<div class="article-meta"><img alt="作者" class="meta" src="<?php echo get_template_directory_uri() . '/icons/user.png'; ?>" width="10" height="12">&nbsp;&nbsp;<?php the_author(); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img alt="发表日期" class="meta" src="<?php echo get_template_directory_uri() . '/icons/calendar.png'; ?>" width="12" height="12"> &nbsp;&nbsp;<?php convention_get_date(); ?></div></div>

<?php the_excerpt(); ?>

<div class="clear"></div>

</div></div>
<?php if ( is_sticky() ) : ?><div class="line-one"></div><?php endif; ?>

<?php endwhile; ?> 

<div class="postnav"><?php if(function_exists('wp_pagenavi')){ wp_pagenavi(); } else { ?><div class="prev"><?php next_posts_link(__('« Previous Entries')) ?></div><div class="next"><?php previous_posts_link(__('Next Entries »')) ?></div> <?php } ?></div>
</div>

<?php endif; ?>
</div>

<div id="sidebars">

<div id="sidebar">
	<?php get_sidebar(); ?>
</div>

</div>

<div class="clear"></div>

</div>


<?php get_footer(); ?>