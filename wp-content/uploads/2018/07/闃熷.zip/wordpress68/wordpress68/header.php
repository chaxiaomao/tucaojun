<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head profile="http://gmpg.org/xfn/11">
<link rel="profile" href="http://gmpg.org/xfn/11" />
<meta http-equiv="content-type" content="<?php bloginfo('html_type') ?>;chartset=<?php bloginfo('charset'); ?>" />
<meta charset="<?php bloginfo('charset'); ?>">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<title><?php wp_title(' - ', true, 'right'); ?><?php if ( is_paged() ){ ?><?php printf( __('Page %1$s of %2$s', ''), intval( get_query_var('paged')), $wp_query->max_num_pages); ?> -
<?php } ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title>
<meta name="keywords" content="<?php if (is_single()){ $keywords = "";$tags = wp_get_post_tags($post->ID);foreach ($tags as $tag ) {$keywords = $keywords . $tag->name . ", ";}echo $keywords;}else{echo ("队室,少先队网站,少先队辅导员,少先队,少先队活动,少先队知识,少先队队歌");} ?>" />
<meta name="description" content="<?php if (is_single()){ echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 180,"");} else{echo ("队室是个人博客,是少先队辅导员的档案室,最专业的少先队工作网站,有关少先队工作计划,少先队活动方案,少先队知识的网站");}?>" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.3/jquery.min.js"></script>
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<?php } ?>
<!-- 请置于所有广告位代码之前 -->
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
</head>
<body <?php body_class(); ?>>

<div id="line"><div class="subpage">
<div class="toppage">
<ul><li class="page_item page-item-3"><a href="http://www.19491013.com/sample-page/" title="关于队室">关于</a></li>
<li class="page_item page-item-1"><a href="http://www.19491013.com/articles-archive/" title="队室文章存档">归档</a></li>
<li class="page_item page-item-2"><a href="http://www.19491013.com/message-board/" title="队室留言">留言</a></li>
<li class="page_item page-item-4"><a href="http://www.19491013.com/the-young-pioneers/" title="常用资料">链接</a></li>
<li class="page_item page-item-5"><a href="http://www.19491013.com/calendar-of-events/" title="少先队活动月历">月历</a></li>
</ul></div>
<div id="deng"><ul>
<li class="deng-1"><a href="http://www.19491013.com/wp-login.php" target="_blank" title="登录队室">登录</a></li>
<li class="deng-1"><a href="http://www.19491013.com/wp-login.php?action=register" target="_blank" title="注册队室">注册</a></li></ul></div>
<div class="clear"></div>
</div>
</div>

<div id="title"><div id="blogtitle"><a href="<?php echo esc_url( home_url() ); ?>"><?php echo bloginfo('name'); ?></a><div id="blogdescription"><?php echo bloginfo('description'); ?></div></div>
<div class="poptip">
    <span class="poptip-arrow poptip-arrow-left"><em>◆</em><i>◆</i></span>
	<p>知道少先队建队日1949年10月13日,就记住 <a href="http://www.19491013.com/sample-page/" target="_blank">队室</a> 的网址了!<a href="javascript:void(0);" onClick="window.external.AddFavorite(document.location.href,document.title)">收藏队室</a></p>
	</div>
<div class="search_1">		
			<form id="searchform_1" method="get" action="http://www.19491013.com">
				<input type="text" value="" name="s" id="s" size="30">
				<button type="submit">搜索</button>
			</form>
		</div>
<div id="rss"><ul>
<li class="rssfeed"><a href="http://www.19491013.com/feed/" target="_blank" class="icon1" title="欢迎订阅队室博客" style="text-indent: 0px;"></a></li>
<li class="tqq"><a href="http://t.qq.com/www200408comcn" rel="external nofollow" target="_blank" class="icon2" title="队室的腾讯微博" style="text-indent: 0px;"></a></li><li class="tsina"><a href="http://weibo.com/u/1591309635" rel="external nofollow" target="_blank" class="icon3" title="队室的新浪微博" style="text-indent: 0px;"></a></li><li class="rssmail"><a href="http://mail.qq.com/cgi-bin/feed?u=http://www.19491013.com/feed/" rel="external nofollow" target="_blank" class="icon4" title="用QQ邮箱阅读空间订阅队室" style="text-indent: 0px;"></a></li></ul></div>
</div>	
<div class="clear"></div>	
		<div id="nav-container">
<div id="nav"><div class="menu">
	<?php wp_nav_menu( array('theme_location' => 'header-nav', 'depth' => 0, 'menu_class' => 'nav' )); ?>

   
	</div></div><div class="clear"></div>
	

	
	
	
	<?php $header_image = get_header_image();
				if ( $header_image ) : ?>
				<div id="header-container"><img class="header" src="<?php header_image(); ?>" height="<?php echo get_custom_header()->height;?>" width="<?php echo get_custom_header()->width; ?>"  alt=""/></div><?php endif; ?>