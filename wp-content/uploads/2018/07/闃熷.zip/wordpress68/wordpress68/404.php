<?php get_header(); ?>

<div id="content">
<div id="articles">


<div id="article">

<div class="article-title"><?php _e( 'Error 404', 'convention' ); ?></div>

<?php _e( 'The site could not be found.', 'convention' ); ?>



</div>


</div>

<div id="sidebars">

<div id="sidebar">
	<?php get_sidebar(); ?>
</div>

</div>

<div class="clear"></div>

</div>


<?php get_footer(); ?>