<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div id="content_center">
			<div class="vedio_box">
				<!--<div class="vedio_main">
					<div style="display:none;">
						<object width="640" height="515"><param name="movie" value="http://share.vrs.sohu.com/941592/v.swf&autoplay=false&xuid="></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed width="100%" height="250"  allowfullscreen="true" allowscriptaccess="always" quality="high" src="http://share.vrs.sohu.com/941592/v.swf&autoplay=false&xuid=" type="application/x-shockwave-flash"/></embed></object>
					</div>
					<a onclick="play(this)">
						<img src="<?php bloginfo('template_url'); ?>/images/1.jpg" width="100%" height="250"/>
					</a>
				</div>-->
				<?php include (TEMPLATEPATH . '/slider.php'); ?>
			</div>
		</div>
		<div id="post_collection">
			<h4>
				<ul class="post_collection_top">
					<li class="current" rel="1">最新发布</li>
					<li rel="2">热点聚焦</li>
					<li rel="3">随便看看</li>
					<li rel="4">精华置顶</li>
					<li rel="5">近期评论</li>
				</ul>
			</h4>
			<div class="tab_list">
				<ul id="tab_1">
					<?php $post_query = new WP_Query('showposts=7');
						while ($post_query->have_posts()) : $post_query->the_post();
						$do_not_duplicate = $post->ID; ?>
						<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title(), 0, 60, ''); ?></a><span class="list_time"><?php the_time('Y-m-d h:i:s'); ?></span></li>
					<?php endwhile;wp_reset_query();?>
				</ul>
				<ul id="tab_2" style="display:none;">
					<?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title,post_date FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 7");  
						foreach ($result as $post) {
							setup_postdata($post);
							$postid = $post->ID;
							$title = $post->post_title;
							$commentcount = $post->comment_count;
							$time = $post->post_date;
								if ($commentcount != 0) { ?>
									<li>
										<a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>"><?php echo mb_strimwidth($title, 0, 60, ''); ?></a><span class="list_time"><?php echo $time;?></span>
									</li>
							<?php
								}
						}wp_reset_query();?>
				</ul>
				<ul id="tab_3" style="display:none;">
					<?php
						global $post;
						$postid = $post->ID;
						$args = array( 'orderby' => 'rand', 'post__not_in' => array($post->ID), 'showposts' => 7);
						$query_posts = new WP_Query();
						$query_posts->query($args);
						while ($query_posts->have_posts()) : $query_posts->the_post(); ?>
							<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title(), 0, 60, ''); ?></a><span class="list_time"><?php the_time('Y-m-d h:i:s'); ?></span></li>
					<?php endwhile; wp_reset_query();?>
				</ul>
				<ul id="tab_4" style="display:none;">
					<?php
						$sticky = get_option('sticky_posts');
						rsort( $sticky );
						$sticky = array_slice( $sticky, 0, 7);
						query_posts( array( 'post__in' => $sticky, 'caller_get_posts' => 1 ) );
						if (have_posts()) :
						while (have_posts()) : the_post();
					?>
					<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title(), 0, 60, ''); ?></a><span class="list_time"><?php the_time('Y-m-d h:i:s'); ?></span></li>
					<?php endwhile; endif;wp_reset_query(); ?>
				</ul>
				<ul id="tab_5" style="display:none;">
					<?php 
						$limit_num = '7'; 
						$my_email = "'" . get_bloginfo ('admin_email') . "'"; 
						$rc_comms = $wpdb->get_results("
						 SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
						 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
						 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
						 WHERE comment_approved = '1'
						 AND comment_type = ''
						 AND post_password = ''
						
						 ORDER BY comment_date_gmt
						 DESC LIMIT $limit_num
						 ");
						$rc_comments = '';
						foreach ($rc_comms as $rc_comm) { //get_avatar($rc_comm,$size='50')
						$rc_comments .= "<li><a href='"
						. get_permalink($rc_comm->ID) . "#comment-" . $rc_comm->comment_ID
						. "' title='本文由".$rc_comm->comment_author."发表在:" . $rc_comm->post_title . "'>" .$rc_comm->comment_author ."说 ".$rc_comm->comment_content
						. "</a></li>\n";
						}
						$rc_comments = convert_smilies($rc_comments);
						echo $rc_comments;wp_reset_query();
					?>
				</ul>
				
			</div>
		</div>