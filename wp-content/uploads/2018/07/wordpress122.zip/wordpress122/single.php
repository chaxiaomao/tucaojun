<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php get_header(); ?>
<?php 
	if ($options['show_full']==1){
		include (TEMPLATEPATH . '/full_single.php');
	}else{?>
	
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>	
<?php	
	include (TEMPLATEPATH . '/classic_single.php');get_sidebar();
	}
?>
<?php get_footer(); ?>
