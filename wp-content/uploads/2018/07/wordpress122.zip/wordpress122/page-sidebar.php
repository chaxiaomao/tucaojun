<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div id="sidebar">
	<?php
		if (is_page()||is_404()):
		if (!dynamic_sidebar('sidebar-3')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
</div>
