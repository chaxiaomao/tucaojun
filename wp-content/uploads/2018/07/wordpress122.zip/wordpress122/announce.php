<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php 
	// 获得后台数据
	$announce = $options['announce'];
	if($announce!=""){
?>
<div class="global_announce" style="margin-bottom:10px">
	<?php echo $announce;?>
</div>
<?php
	}
?>