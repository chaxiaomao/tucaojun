<?php
/*
Template Name: links
*/
?>
<?php get_header(); ?>
<div id="content">
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<?php setPostViews(get_the_ID()); ?>
				<div class="s_position">
					<a href="<?php bloginfo('url'); ?>">首页</a>>><?php  echo the_title(); ?>
				</div>
				<div class="s_content">
					<div class="s_panel">
						<h2><?php echo the_title(); ?></h2>
						<div class="s_info">
							<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
						</div>
							<ul>
								<div class="countPanel"><span class="tagText">链接总数</span>:<?php $link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?></div>
								<?php the_content(); ?>
								<?php wp_list_bookmarks('orderby=id&categorize=0&category=2&title_li='); ?>
							</ul>
					</div>
	
				</div>
			<?php endwhile; ?>
			</div>
<?php include (TEMPLATEPATH . '/page-sidebar.php'); ?>
<?php get_footer(); ?>
