<?php
/**
 * 2.2版文章列表显示方式
 */
?>
<?php $options = get_option( 'AesRoom_theme_settings' ); $random=$options['random_image'];$content=get_the_content();?>
<div class="cool-post-box">
		<div class="cool-post-img">
			<?php if ( has_post_thumbnail() ) { ?>
			<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><?php the_post_thumbnail(); ?>
				<?php if(strpos($content,"embed")){?>
				<span class="cool-title"><div class="v"><?php echo getPostViews(get_the_ID()); ?></div> <div class="c"><?php comments_number('0','1','%'); ?></div></span>
				<?php }else if(strpos($content,"gallery")){?>
				<span class="cool-title"><div class="p"><?php echo getPostViews(get_the_ID()); ?></div> <div class="c"><?php comments_number('0','1','%'); ?></div></span>
				<?php }else{?>
				<span class="cool-title"><div class="in"><?php echo getPostViews(get_the_ID()); ?></div> <div class="c"><?php comments_number('0','1','%'); ?></div></span>
				<?php }?>
			</a>
			<?php } else {?>
			<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>">
				<img src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,$random)?>.jpg" />
				<?php if(strpos($content,"embed")){?>
				<span class="cool-title"><div class="v"><?php echo getPostViews(get_the_ID()); ?></div> <div class="c"><?php comments_number('0','1','%'); ?></div></span>
				<?php }else if(strpos($content,"gallery")){?>
				<span class="cool-title"><div class="p"><?php echo getPostViews(get_the_ID()); ?></div> <div class="c"><?php comments_number('0','1','%'); ?></div></span>
				<?php }else{?>
				<span class="cool-title"><div class="in"><?php echo getPostViews(get_the_ID()); ?></div> <div class="c"><?php comments_number('0','1','%'); ?></div></span>
				<?php }?>
			</a>
			<?php } ?>
		</div>
		<div class="cool-post-content">
			<div class="cool-post-title">
				<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><?php the_title(); ?></a>
				<br>
				<?php echo smc_time_since(get_post_time('U', true))?>
				<br>
			<?php 
     			  $url = get_bloginfo('template_url');
				if(strpos($content,"embed")){
					$first = stripos($content,"embed");
					$end = strripos($content,"</embed>");
					if($end==null){
						
						$end = strripos($content,"</object>");
					}
					$c = substr($content,$first,$end-$first-1);
					$embedPath = "<".$c.">";
				echo "<div class='cool-vedio-icon' title='单击播放视频' onclick='coolPlay(this)'></div><div style='display:none' class='vedio_box'>".$embedPath."</div>";
				}else{
					echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");
				}
				?>
			</div>
			<div class="cool-tags"><?php the_tags('','&nbsp;'); ?></div>
		</div>
		<div class="cool-read"><a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><img src="<?php bloginfo('template_url'); ?>/images/read.png" width="43" height="212"></a></div>
</div>
<div class="cool-clear"></div>
