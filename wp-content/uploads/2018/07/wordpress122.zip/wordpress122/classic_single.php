<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div id="content">
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<?php setPostViews(get_the_ID()); ?>
				<div class="s_position">
					<a href="<?php bloginfo('url'); ?>">首页</a>>><?php the_category(' '); ?>>>文章阅读
					<span class="font-style">字体:<a id="small">小</a> <a id="middle">中</a> <a  id="big">大</a></span>
				</div>
				<div class="s_content">
					<div class="s_panel">
						<div class="before"><span>上一篇:</span>
							<?php if (get_previous_post()) { 
								previous_post_link('%link');
								} else {
								echo "到头啦.";
							} ?>
						</div>
						<h2><?php the_title(); ?></h2>
						<div class="s_info">
							<span class="date">日期:<?php the_time('Y-m-d H:i:s'); ?></span>
							<span class="view">浏览:<?php echo getPostViews(get_the_ID()); ?></span>
							<span class="comt">评论:<a href="#comment"><?php comments_number('0条','1条','%条'); ?></a></span>
							<span class="comt">作者:<?php the_author(); ?></span>
							<?php edit_post_link( __('重新编辑'), '<span class="edit">', '</span>' ); ?>
							<?php if (comments_open()) : ?><span class="ico cmt add"><a href="#comment">评论</a></span><?php endif; ?>
						</div>
						<?php
							$themeurl = get_bloginfo('template_url');
						?>
						<?php 
							$article = $options['article'];
							$article_value = $options['article_value'];
						?>
						<?php if($article==1){?>
						<div id="article_ad">
							<?php if($article_value!=""){?>
								<?php echo $options['article_value'];?>
							<?php }else{?>
								<img src="<?php echo $themeurl;?>/images/article.jpg" width="200" height="200"/>
							<?php }?>

						</div>
						<?php }?>
						<div id="post-content">
						<?php the_content(); ?>
						</div>
						<?php if (get_the_tags()): ?>
							<br/><br/>
							<span class="tags"><?php the_tags('','&nbsp;'); ?></span>
						<?php endif; ?>
						<script type="text/javascript">
							$(".gallery").galleria();
						</script>
						<div class="next"><span>下一篇:</span>
						<?php if (get_next_post()) {
								next_post_link('%link');
								} else {
								  echo "到底啦.";
								}?>
						</div>

					</div>

				</div>
				<div class="single_author">
					作者:<?php the_author(); ?>
					<br/>
					最后更新时间:<?php the_modified_time('Y-m-d H:i:s'); ?>
					<br/>
					链接:<?php the_permalink(); ?>
				</div>
				<?php include (TEMPLATEPATH . '/relationsdiary.php'); ?>
				<?php if (comments_open()) comments_template( '', true ); ?>
				
			</div>
		<?php endwhile; ?>