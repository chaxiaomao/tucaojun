<div class="single_relations">
					<h2>
						您可能喜欢的
					</h2>
					<ul>
						<?php
$cats = wp_get_post_categories($post->ID);
if ($cats) {

$cat = get_category( $cats[0] );
$first_cat = $cat->cat_ID;
$args = array(
        'category__in' => array($first_cat),
        'post__not_in' => array($post->ID),
        'showposts' => 6,
        'caller_get_posts' => 1
    );
query_posts($args);

if (have_posts()) :
    while (have_posts()) : the_post(); update_post_caches($posts); ?>
<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a></li>
<?php endwhile; else : ?>
<li>暂无相关文章</li>
<?php endif; } wp_reset_query();?>
					</ul>
				</div>
				<div class="single_random">
					<h2>
						随即推荐给您
					</h2>
					<ul>
						<?php $rand_posts = get_posts('numberposts=6&orderby=rand');foreach($rand_posts as $post) : ?> 
						<li><a href="<?php the_permalink(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a></li> 
						<?php endforeach;wp_reset_query();?> 
					</ul>
				</div>