<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div class="single_relations">
					<div class="single_relations_title">
						<a href="<?php echo get_category_link($options['cat_1']);?>" title="查看分类《<?php echo get_category($options['cat_1'])->name;?>》下的文章"><?php echo get_category($options['cat_1'])->name;?></a>
					</div>
					
					<ul>
						<?php
							$random=$options['random_image'];
							if($random=="")$random=6;
							$index = 1;
							query_posts('posts_per_page='.'5'.'&cat='.$options['cat_1']);  
							while(have_posts()) : the_post(); 
							if($index==1){
						?>
						<li class="loop_img">
							<div class="l_imgbox">
							<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_post_thumbnail(); ?></a>
							<?php } else {?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><img src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,$random)?>.jpg"/></a>
							<?php } ?>
							</div>
							<div class="l_text">
								<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="firstdiary" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a><br/>
								<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 45,"...");?>
							</div>
						</li>
						<?php }else{ ?>
<li>* <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a></li>
<?php } $index++;?>
<?php endwhile;wp_reset_query();?>
					</ul>
					<i class="lt"></i>
					<i class="rt"></i>
					<i class="lb"></i>
					<i class="rb"></i>
				</div>
				<div class="single_random">
					<div class="single_relations_title">
						<a href="<?php echo get_category_link($options['cat_2']);?>" title="查看分类《<?php echo get_category($options['cat_2'])->name;?>》下的文章"><?php echo get_category($options['cat_2'])->name;?></a>
					</div>
					<i class="lt"></i>
					<i class="rt"></i>
					<i class="lb"></i>
					<i class="rb"></i>
					<ul>
						<?php  
							$index = 1;
							query_posts('posts_per_page='.'5'.'&cat='.$options['cat_2']);  
							while(have_posts()) : the_post();  
							if($index==1){
						?> 
						<li class="loop_img">
							<div class="l_imgbox">
							<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_post_thumbnail(); ?></a>
							<?php } else {?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><img src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,$random)?>.jpg"/></a>
							<?php } ?>
							</div>
							<div class="l_text">
								<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="firstdiary" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a><br/>
								<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 45,"...");?>
							</div>
						</li>
						<?php }else{ ?>
<li>* <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a></li>
<?php } $index++;?>
<?php endwhile;wp_reset_query();?>
					</ul>
				</div>
<div class="single_relations">
					<div class="single_relations_title">
						<a href="<?php echo get_category_link($options['cat_3']);?>" title="查看分类《<?php echo get_category($options['cat_3'])->name;?>》下的文章"><?php echo get_category($options['cat_3'])->name;?></a>
					</div>
					
					<ul>
						<?php  
							$index = 1;
							query_posts('posts_per_page='.'5'.'&cat='.$options['cat_3']);  
							while(have_posts()) : the_post(); 
							if($index==1){
						?>
						<li class="loop_img">
							<div class="l_imgbox">
							<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_post_thumbnail(); ?></a>
							<?php } else {?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><img src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,$random)?>.jpg"/></a>
							<?php } ?>
							</div>
							<div class="l_text">
								<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="firstdiary" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a><br/>
								<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 45,"...");?>
							</div>
						</li>
						<?php }else{ ?>
<li>* <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a></li>
<?php } $index++;?>
<?php endwhile;wp_reset_query();?>
					</ul>
					<i class="lt"></i>
					<i class="rt"></i>
					<i class="lb"></i>
					<i class="rb"></i>
				</div>
				<div class="single_random">
					<div class="single_relations_title">
						<a href="<?php echo get_category_link($options['cat_4']);?>" title="查看分类《<?php echo get_category($options['cat_4'])->name;?>》下的文章"><?php echo get_category($options['cat_4'])->name;?></a>
					</div>
					<i class="lt"></i>
					<i class="rt"></i>
					<i class="lb"></i>
					<i class="rb"></i>
					<ul>
						<?php  
							$index = 1;
							query_posts('posts_per_page='.'5'.'&cat='.$options['cat_4']);  
							while(have_posts()) : the_post();  
							if($index==1){
						?> 
						<li class="loop_img">
							<div class="l_imgbox">
							<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_post_thumbnail(); ?></a>
							<?php } else {?>
							<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><img src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,$random)?>.jpg"/></a>
							<?php } ?>
							</div>
							<div class="l_text">
								<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="firstdiary" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a><br/>
								<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 45,"...");?>
							</div>
						</li>
						<?php }else{ ?>
<li>* <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" excep="<?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 200,"...");?>"><?php the_title(); ?></a></li>
<?php } $index++;?>
<?php endwhile;wp_reset_query();?>
					</ul>
				</div>
<script>
	jQuery(".post-box").eq(0).css("margin-bottom","10px");
</script>
