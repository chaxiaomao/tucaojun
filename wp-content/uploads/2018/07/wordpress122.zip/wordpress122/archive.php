<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
		<div class="s_position" style="margin-bottom:10px">
		


			<?php
				$themeurl = get_bloginfo('template_url');
				$mainUrl = get_bloginfo('url');
				$random=$options['random_image'];
				if (is_category()) {
					printf("栏目:
				<span class='cate_spe'>".single_cat_title('', false)."</span> 下的所有文章" );
					if (category_description()) echo '<p>'.category_description().'</p>';
				} elseif (is_tag()) {
					printf("标签:
				<span class='cate_spe'>".single_tag_title('', false).'</span> 下的所有文章</h3>' );
					if (tag_description()) echo '<p>'.tag_description().'</p>';
				} elseif (is_day()) {
					printf('
				'.get_the_time('Y年n月j日').'' );
				} elseif (is_month()) {
					printf('
					'.get_the_time('Y年n月').'' );
				} elseif (is_year()) {
					printf('
					'.get_the_time('Y年').'' );
				} elseif (is_author()) {
						echo '作者存档';
				} elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {
					echo '博客存档';
				}
				?>
				
				<span style="float:right;float: right;font-weight: bold;cursor:pointer">浏览方式:<?php articlesOrder();?></span>
		</div>
		
	<?php if (!is_page()){include (TEMPLATEPATH . '/announce.php');} ?>
	<?php if (have_posts()) : while ( have_posts() ) : the_post();?>
	<?php 
		include (TEMPLATEPATH . '/cool_post_loop.php'); 
	?>	
		<?php endwhile; ?>

		<?php pagination($query_string); ?>
		<?php else : ?>
		<div class="s_content">
		<img src="<?php echo $themeurl;?>/images/404.jpg"/>
		<p>没有找到任何文章！
		</div>
		<?php endif; ?>
	</div>	
<?php
	get_sidebar();
	get_footer(); ?>

