<?php
/*
Template Name: tags
*/
?>
<?php get_header(); ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
<?php setPostViews(get_the_ID()); ?>
<div id="content">
	<div class="s_position">
		<a href="<?php bloginfo('url'); ?>">首页</a>>><?php  echo the_title(); ?>
	</div>
	<div class="s_content">
		<div class="s_panel" id="tagPanel">
			<h2><?php echo the_title(); ?></h2>
			<div class="s_info">
				<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
			</div>
				<div class="countPanel"><span class="tagText">标签总数</span>:<?php echo $count_tags = wp_count_terms('post_tag'); ?></div>
				<?php the_content(); ?>
				<?php wp_tag_cloud('number=0&orderby=count'); ?>
				<script>
				jQuery("#tagPanel li a").append("<span></span>");
				jQuery("#tagPanel li a").find("span").html( function(){var s=$(this).parent().attr("title").replace(/[^0-9]/ig, "");
				return "[+"+parseInt(s)+"]";});
				</script>
		</div>

	</div>
</div>
<?php endwhile; ?>
<?php include (TEMPLATEPATH . '/page-sidebar.php'); ?>
<?php get_footer(); ?>
