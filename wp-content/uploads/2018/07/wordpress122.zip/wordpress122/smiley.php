﻿<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php
	$themeurl = get_bloginfo('template_url');
	$smile = $options['smile'];
	if($smile==""){
		$smile="qq_2";
	}
	echo "<script>var smile ='".$smile."'; </script>"
?>
<script type="text/javascript">
/* <![CDATA[ */
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
    		myField = document.getElementById('comment');
    	} else {
    		return false;
    	}
    	if (document.selection) {
    		myField.focus();
    		sel = document.selection.createRange();
    		sel.text = tag;
    		myField.focus();
    	}
    	else if (myField.selectionStart || myField.selectionStart == '0') {
    		var startPos = myField.selectionStart;
    		var endPos = myField.selectionEnd;
    		var cursorPos = endPos;
    		myField.value = myField.value.substring(0, startPos)
    					  + tag
    					  + myField.value.substring(endPos, myField.value.length);
    		cursorPos += tag.length;
    		myField.focus();
    		myField.selectionStart = cursorPos;
    		myField.selectionEnd = cursorPos;
    	}
    	else {
    		myField.value += tag;
    		myField.focus();
    	}
    }
/* ]]> */
</script>
<div id="smilelink">
<a onclick="javascript:grin(':?:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_question.gif" title="疑问" alt="疑问" /></a>
<a onclick="javascript:grin(':razz:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_razz.gif" title="可爱" alt="可爱" /></a>
<a onclick="javascript:grin(':sad:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_sad.gif" title="难过" alt="难过" /></a>
<a onclick="javascript:grin(':evil:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_evil.gif" title="鄙视" alt="鄙视" /></a>
<a onclick="javascript:grin(':!:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_exclaim.gif" title="吃惊" alt="吃惊" /></a>
<a onclick="javascript:grin(':smile:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_smile.gif" title="微笑" alt="微笑" /></a>
<a onclick="javascript:grin(':oops:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_redface.gif" title="害羞" alt="害羞" /></a>
<a onclick="javascript:grin(':grin:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_biggrin.gif" title="使坏" alt="使坏" /></a>
<a onclick="javascript:grin(':eek:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_surprised.gif" title="惊讶" alt="惊讶" /></a>
<a onclick="javascript:grin(':shock:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_eek.gif" title="发呆" alt="发呆" /></a>
<a onclick="javascript:grin(':???:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_confused.gif" title="撇嘴" alt="撇嘴" /></a>
<a onclick="javascript:grin(':cool:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_cool.gif" title="耍酷" alt="耍酷" /></a>
<a onclick="javascript:grin(':lol:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_lol.gif" title="偷笑" alt="偷笑" /></a>
<a onclick="javascript:grin(':mad:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_mad.gif" title="可恶" alt="可恶" /></a>
<a onclick="javascript:grin(':twisted:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_twisted.gif" title="愤怒" alt="愤怒" /></a>
<a onclick="javascript:grin(':roll:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_rolleyes.gif" title="白眼" alt="白眼" /></a>
<a onclick="javascript:grin(':wink:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_wink.gif" title="鼓掌" alt="鼓掌" /></a>
<a onclick="javascript:grin(':idea:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_idea.gif" title="得意" alt="得意" /></a>
<a onclick="javascript:grin(':arrow:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_arrow.gif" title="擦汗" alt="擦汗" /></a>
<a onclick="javascript:grin(':neutral:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_neutral.gif" title="发困" alt="发困" /></a>
<a onclick="javascript:grin(':cry:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_cry.gif" title="哭" alt="哭" /></a>
<a onclick="javascript:grin(':mrgreen:')"><img src="<?php bloginfo('template_url');?>/images/smilies/<?php echo $smile?>/icon_mrgreen.gif" title="大笑" alt="大笑" /></a>
</div>
<script type="text/javascript" language="javascript">
	var src = "";
	for(var i=0;i<$('.wp-smiley').length;i++){
		src = $('.wp-smiley').eq(i).attr("src");
		var newSrc = src.substr(0,src.indexOf('smilies')+7)+"/"+smile+src.slice(src.indexOf('smilies')+7);
		$('.wp-smiley').eq(i).attr("src",newSrc);
	}
</script>