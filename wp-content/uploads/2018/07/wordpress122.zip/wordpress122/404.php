<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php get_header(); ?>
<?php
	$themeurl = get_bloginfo('template_url');
?>
<div id="content">
	<div class="s_position">
		<a href="<?php bloginfo('url'); ?>">首页</a>>>404了
	</div>
	<div class="s_content">
		<div class="s_panel">
			<h2>404-找不到您要访问的页面</h2>
			<div class="s_info">
				<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
			</div>
				<img src="<?php echo $themeurl;?>/images/404.jpg"/>
		</div>

	</div>
</div>
<?php include (TEMPLATEPATH . '/page-sidebar.php'); ?>
<?php get_footer(); ?>