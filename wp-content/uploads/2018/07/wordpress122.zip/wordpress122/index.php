<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php get_header(); $themeurl = get_bloginfo('template_url');?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<?php
	if (is_home()){
		include (TEMPLATEPATH . '/tab.php');
	} 
?>	
<div id="content">
	<div id="list_icon">
		<strong style="color: #3cb6e7; font-size: 14px;">最新发布</strong>
		<span style="float:right;color: #3cb6e7;float: right;font-weight: bold;cursor:pointer">浏览方式:<?php articlesOrder();?></span>
	</div>
	<?php if (!is_page()){include (TEMPLATEPATH . '/announce.php');} ?>
	<?php if (have_posts()) : while ( have_posts() ) : the_post();?>
	<?php 
		include (TEMPLATEPATH . '/cool_post_loop.php'); 
	?>	
	<?php endwhile; ?>
	<?php pagination($query_string); ?>
	<?php endif; ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
