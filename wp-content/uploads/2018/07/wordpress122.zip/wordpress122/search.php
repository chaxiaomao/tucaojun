<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php get_header(); $themeurl = get_bloginfo('template_url');?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="s_position" style="margin-bottom:10px">"<?php echo $_GET["s"];?>"的搜索结果</div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php 
	include (TEMPLATEPATH . '/cool_post_loop.php'); 
?>	
		
<?php endwhile;?>
		<?php pagination($query_string); ?>
<?php else : ?>
<div class="s_content">
	
	<div class="s_panel">
		<h2>您要找的文章不存在</h2>
		<div class="s_info">
			<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
		</div>
			<img src="<?php echo $themeurl;?>/images/404.jpg"/>
	</div>

</div>
<?php endif; ?>
<?php
	wp_reset_query();
?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
