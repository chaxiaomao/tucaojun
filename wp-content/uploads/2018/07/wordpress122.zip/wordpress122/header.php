<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title><?php wp_title(''); ?> <?php bloginfo( 'name' ); ?></title>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<link href="<?php bloginfo('template_url');?>/style.css" rel="stylesheet" type="text/css" id="default_style"/>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="icon" href="<?php echo $options['upload_favicon']; ?>" type="image/x-icon"/>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery-1.6.min.js"></script>
<script type='text/javascript' src='<?php bloginfo('template_url');?>/js/color-animate.js'></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/lazyload.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.galleria.js"></script>

<?php echo 
"<script type='text/javascript'>
	var maxNum=".($options['slide_num']-1).";
</script>";
?>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/functions.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/move.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/updown.js"></script>
<script type="text/javascript">
	$("img.lazy").lazyload();
	function ceshi(obj){
		
		$(obj).parent().find("div").css("display","block");
		$(obj).remove();
	}
	
</script>
<?php
	
	if (is_single()){
	$tags = wp_get_post_tags($post->ID);
			foreach ($tags as $tag ) {
				$keywords = $keywords . $tag->name . ",";
			}
?>
<meta name="keywords" content="<?php echo substr($keywords,0,strlen($keywords)-1); ?>" />
<meta name="description" content="<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100,"..."); ?>" />
<?php
	}
	else if (is_home()) {
?>
<meta name="keywords" content="<?php echo $options['index_key']; ?>" />
<meta name="description" content="<?php echo $options['index_desc']; ?>" />
<?php }
	else if (is_category) {
		if($options[the_category_ID('',false)]!=""){
?>
<meta name="keywords" content="<?php echo $options[the_category_ID('',false)];?>" />
<?php 
		}else{
?>
<meta name="keywords" content="<?php echo $options['index_key']; ?>" />
<?php 
		}
		if($options[single_cat_title('', false)]!=""){
?>
<meta name="description" content="<?php echo $options[single_cat_title('', false)]; ?>" />
<?php 
		}
		else{
?>
<meta name="description" content="<?php echo $options['index_desc']; ?>" />
<?php
		}
	}
	if((is_home()||is_category)){
?>

<?php

	}
?>
<?php 
	if($options['bg']!="")
	echo "<style>body{background:url(".$options['bg'].") repeat;}</style>";	
	if($options['bgColor']!="")
	echo "<style>body{background:".$options['bgColor']."}</style>";	
?>
<?php 
	if($options['changesidebar']==1)
	echo "<style>#content{float:right;}#sidebar{float:left;}</style>";	
?>
<!--[if lt IE 9]>
			<style>
				.content{
					height: auto;
					margin: 0;
				}
				.content div {
					position: relative;
				}
				#sidebar{
					margin-left:-5px;
				}
			</style>
		<![endif]-->
		
		<script type="text/javascript">
	
	jQuery(function($) {
		
		var $liveTip = $('<div id="livetip"></div>').hide().appendTo('body');
		var tipTitle = '';
		$(".single_relations li,.single_random li").bind('mouseover mouseout mousemove', function(event) {
		var $link = $(event.target).closest('a');
		if (!$link.length) {
			return; 
		}
		var link = $link[0];
		if (event.type == 'mouseover' || event.type == 'mousemove') {
			$liveTip.css({
			top: event.pageY + 12,
			left: event.pageX + 12
			});
		};
		if (event.type == 'mouseover') {
			tipTitle = $(link).attr("excep");
			link.title = '';
			$liveTip.html('<div>' + tipTitle + "</div><div>继续阅读:<a href='"+link.href + "'>"+link.href+"</a></div>")
			.show(300);
		};
		if (event.type == 'mouseout') {
			$liveTip.hide();
			if (tipTitle) {
			link.title = tipTitle;
		};
	};
});
});
</script>
</head>
<body>
<div id="container">
	<div id="head">
		
		
			<div id="logo">
				<?php
					if ($options['logo']!=""){
				?>
				<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo( 'name' ); ?>"><img src="<?php echo $options['logo']; ?>" width="230" height="35"/></a>
				<?php 
					}else{
				?>
				<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo( 'name' ); ?>"><img src="<?php bloginfo('template_url');?>/images/logo.png" width="230" height="35"/></a>
				<?php
					}
				?>
				
			</div>
			<div class="search">
				<form>
					<input type="text" placeholder="搜索" maxlength="30" name="s" class="ipt" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<button type="submit" class="sbtn"></button>
				</form>
			</div>
			<?php if(is_user_logged_in()) {  
				$user_id = get_current_user_id();
				$current_user = wp_get_current_user();
				$profile_url = get_author_posts_url($user_id);
				$edit_profile_url  = get_edit_profile_url($user_id);
				?>
				<div id="account-nav" class="user-nav">
					<a class="dropdown-handle" href="<?php echo $profile_url; ?>">
						<?php echo get_avatar( $user_id, 32 ); ?>
						<span class="display-name btn"><span class="arrow-down"><?php echo $current_user->display_name; ?></span></span>
					</a>
							
					<div class="dropdown-content">
						<ul class="dropdown-content-inner">
							<li><a class="profile-link" href="<?php echo $profile_url; ?>">个人资料</a></li>
							<li><a class="account-link" href="<?php echo $edit_profile_url; ?>">控制面板</a></li>
							<li><a class="logout-link" href="<?php echo esc_url(wp_logout_url($current_url)); ?>">退出</a></li>
						</ul>
					</div>
				</div>
			<?php } else { ?>
				<div id="login-nav" class="user-nav">
					<a class="btn btn-green register-link" href="<?php echo site_url('wp-login.php?action=register', 'login'); ?>">注册</a>
						
					<div class="dropdown">
						<a class="dropdown-handle btn btn-black login-link" href="<?php echo wp_login_url(); ?>">登录</a>
							
						<div class="dropdown-content"><div class="dropdown-content-inner">
							<?php wp_login_form(); ?>
						</div></div>
					</div>
				</div>
			<?php }?>
		<div id="nav">	
			<?php wp_nav_menu( array( 'container_id' => 'menu', 'theme_location' => 'primary','fallback_cb'=> '' ) ); ?>
		</div>
		
		<div id="user_feeling">
			<?php
				if (is_home()) {
					echo $options['index_view']; 
				}else if(is_category()){
					echo $options['cat_'.the_category_ID('',false)]; 
				}
				else if (is_single()){
					echo $options['post_'.$post->ID]; 
				}
				else if (is_page()){
					echo $options['page_'.$post->ID]; 
				}
			?>
			
		</div>
		
	</div>
	<!--head结束-->
	<?php
		if ($options['slide']==1&&is_home()){
	?>
	<?php
		$themeurl = get_bloginfo('template_url');
		$slide_value = $options['slide_value'];
		$slide_space = $options['slide_space'];
	?>
	<div style="position:relative; display: block; margin: 0pt auto; width: 1070px;"  id="divplay"><div id="playbtn"></div><div id="closebtn"></div></div>
	<div id="slide">
		<?php if($slide_value!=""){?>
			<a href="<?php echo $options['slide_href'];?>" rel="nofollow" target="_blank"><img src="<?php echo $options['slide_value'];?>" width="1070" height="500"/></a>
			
		<?php }else{?>
			<a href="<?php echo $options['slide_href'];?>" rel="nofollow" target="_blank">请先设置图片地址</a>
		<?php }?>
	</div>
	<?php }?>
	<div style="display:none;" id="slide_space_ad">
		<?php if($slide_space!=""){?>
			<a href="<?php echo $options['slide_space_href'];?>" rel="nofollow" target="_blank"><img src="<?php echo $options['slide_space'];?>" width="1070" height="65"/></a>
			
		<?php }else{?>
			<a href="<?php echo $options['slide_space_href'];?>" rel="nofollow" target="_blank">请先设置图片地址</a>
		<?php }?>
		
	</div>
	
	