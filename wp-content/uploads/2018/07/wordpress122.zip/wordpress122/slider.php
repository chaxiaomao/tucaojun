<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php $themeurl = get_bloginfo('template_url');?>
<?php 
	$cateId = $options['index_slide_id'];
	$cateNum =$options['index_slide_num'];
?>
<div id="wowslider-container1">
	<div class="ws_images">
		<?php 
				query_posts("showposts=".$options['index_slide_num']."&cat=".$cateId)?>
			<ul>
				<?php while (have_posts()) : the_post(); ?>
					<li>
					<?php if ( has_post_thumbnail() ) { ?>

					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_post_thumbnail(array(398,250),array(
	
						'title'	=> get_the_title(),
					)); ?></a>
					<?php } else {?>
					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><img width="398" height="250" src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,6)?>.jpg"  width="310" height="250" title="<?php the_title(); ?>"/></a>
					<?php } ?>
				</li>
				<?php endwhile; ?>
			</ul>
		
	</div>
	<div class="ws_bullets"><div>
		<?php 
				query_posts("showposts=".$options['index_slide_num']."&cat=".$cateId)?>
				<?php while (have_posts()) : the_post(); ?>
				<?php if ( has_post_thumbnail() ) { ?>
	
					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_post_thumbnail(array(143,90),array(
	
						'title'	=> get_the_title(),
					)); ?></a>
					<?php } else {?>
					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><img width="143" height="90" src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,6)?>.jpg"  width="310" height="250" title="<?php the_title(); ?>"/></a>
					<?php } ?>
				<?php endwhile; ?>
	</div>
</div>
<div class="ws_shadow"></div>
</div>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/functions/slider/wowslider.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/functions/slider/script.js"></script>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/functions/slider/style.css" />