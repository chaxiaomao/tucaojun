/*幻灯片切换*/
var movepic;
var nowpic = 0;
function slide() {
	movepic = setInterval(function() {
		nowpic = jQuery("#imgBox ul li.current").index(), nextpic = nowpic + 1;
		if (nowpic == maxNum) {
			nextpic = 0;
		}
		fadePic(nowpic, nextpic);
	}, 3000);
}

/*经典站内播放*/
function play(obj){
	$(obj).parent().find("div").css("display","block");
	$(obj).remove();
}

/*2.2版弹窗播放*/
function coolPlay(obj){
	var vedioCode = $(obj).parent().find("div[class='vedio_box']").html();
	var vedioWin = window.open ('','vedioWin','height=500,width=600,top=0,left=0,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no') ;
	vedioWin.document.write("<style>embed{width:100%;height:100%}</style>");
	vedioWin.document.write(vedioCode);
}



/**
 * 查看完整图片
 */
function view_control(img_src){
	$('#view_box').html("<img src='"+img_src+"'/><span id='close_btn' onclick='clearViewBox()'></span>").fadeIn(600);
	var img = new Image;
	var img_width=0;
	img.onload = function(){
		img_width=img.width;
		var a = ($(window).width()-img_width)/2;
		$('#view_box').css('left',a);
		$('#view_box').css('top',200);
		$('#view_shadow').css({width:$(window).width(),height:$(window).height(),display:"block",background:"#000",position:"fixed"});
	};
	img.src = img_src;
}

/**
 * 关闭蒙版
 */
function clearViewBox(){
	$('#view_box').html("").fadeOut(600);
	$('#view_shadow').fadeOut(600);
}


/**
 * 初始化图片预览窗口
 */
function initViewBox(){
	var post_image_length = $('#post-content').find('a').length;
	if(post_image_length>0){
		var img_a_array = new Array();//符合条件链接长度
		var img_a_obj_array = new Array();//存储符合条件对象
		var img_length = 0;//图片数量
		for(var i=0;i<post_image_length;i++){
			var img_a = $('#post-content').find('a').eq(i).find("img[class*='alignnone']");
			if(img_a!=null&&img_a.length>0){
				img_length++;
				img_a_array.push($(img_a).parent().attr('href'));
				img_a_obj_array.push($(img_a).parent());
			}
		}
		if(img_length>0){
			for(var i=0;i<img_length;i++){
				var url = img_a_array[i];
				var function_text = "javascript:view_control('"+url+"')";
				$(img_a_obj_array[i]).attr("href",function_text);
				$(img_a_obj_array[i]).after("<div class='image_view' onclick=view_control('"+url+"') ></div>");
			}
		}
	}
}

/* 幻灯片切换逻辑 */
function fadePic(nowpic, nextpic) {

	jQuery("#imgNum ul li span").eq(nowpic).removeClass("current");
	jQuery("#imgNum ul li span").eq(nextpic).addClass("current");
	var url = jQuery("#imgBox ul li img").eq(
			$("#imgNum ul li span.current").index("#imgNum ul li span"))
			.parent().attr("href");
	jQuery(".imgTitle").html(
			"<a href='"
					+ url
					+ "'>"
					+ jQuery("#imgBox ul li img").eq(
							$("#imgNum ul li span.current").index(
									"#imgNum ul li span")).attr("title")
					+ "</a>");
	// alert(jQuery("#imgBox ul li img").eq($("#imgNum ul li
	// span.current").index("#imgNum ul li span")).attr("title"));

	jQuery("#imgBox ul li").eq(nowpic).animate({
		'opacity' : '0'
	}, 700).removeClass("current");
	jQuery("#imgBox ul li").eq(nextpic).animate({
		'opacity' : '1'
	}, 700, function() {
	}).addClass("current");
}

$(function() {
	initViewBox();
	
	$(window).scroll(function(){
	   if($(this).scrollTop() <80){
			$("#roll").fadeOut("slow");
		}else{
			$("#roll").fadeIn("slow");
		}
	});
	
	
	/**
	 * 翻页
	 */
	if($('#next_link').html()!=null){
		if($('#next_link').html().trim()=='end'){
			$('#next_a').css('display','none');
		}else{
			$('#next_a').attr('href',$('#next_link').find('a').attr('href'))
		}
	}
	if($('#prev_link').html()!=null){
		if($('#prev_link').html().trim()=='end'){
			$('#prev_a').css('display','none');
		}else{
			$('#prev_a').attr('href',$('#prev_link').find('a').attr('href'))
		}
	}

	/*文章幻灯相关*/
	Galleria.addTheme({
    name: 'classic',
    author: 'Galleria',
    version: '1.5',
    defaults: {
        transition: 'slide',
        thumb_crop: 'height',
        
		// set this to false if you want to show the caption all the time:
        _toggle_info: true
    },
    init: function(options) {
        
        // add some elements
        this.addElement('info-link','info-close');
        this.append({
            'info' : ['info-link','info-close']
        });
        
        // cache some stuff
        var toggle   = this.$('image-nav-left,image-nav-right,counter'),
            info     = this.$('info-link,info-close,info-text'),
            click    = Galleria.TOUCH ? 'touchstart' : 'click';
        
        // show loader & counter with opacity
        this.$('loader,counter').show().css('opacity',.8)

        // some stuff for non-touch browsers
        if (! Galleria.TOUCH ) {
            
            // fade thumbnails
            this.$('thumbnails').children().hover(function() {
                $(this).not('.active').children().stop().fadeTo(100, 1);
            }, function() {
                $(this).not('.active').children().stop().fadeTo(400, .6);
            });
            
            this.addIdleState( this.get('image-nav-left'), { left:-50 });
            this.addIdleState( this.get('image-nav-right'), { right:-50 });
            this.addIdleState( this.get('counter'), { opacity:0 });
        }
        
        // toggle info
        if ( options._toggle_info ) {
            info.bind( click, function() {
                info.toggle();
            });
        }
        
        // bind some stuff
        this.bind(Galleria.THUMBNAIL, function(e) {
            $(e.thumbTarget).parent(':not(.active)').children().css('opacity',.6)
        });
        
        this.bind(Galleria.LOADSTART, function(e) {
            if (!e.cached) {
                this.$('loader').show().fadeTo(200, .6);
            }
            
            this.$('info').toggle( this.hasInfo() );
            
            $(e.thumbTarget).css('opacity',1).parent().siblings().children().css('opacity',.8);
        });
        
        this.bind(Galleria.LOADFINISH, function(e) {
            this.$('loader').fadeOut(200);
        });
    }
});

	/*文章浏览字体大小*/
	var small = document.getElementById('small');
	var middle = document.getElementById('middle');
	var big = document.getElementById('big');
	var post_content = document.getElementById('post-content');
	if(small!=null){
		small.onclick = function(){
			post_content.style.fontSize='12px';
		};
	}
	if(middle!=null){
		middle.onclick = function(){
			post_content.style.fontSize='15px';
		};
	}
	if(big!=null){
		big.onclick = function(){
			post_content.style.fontSize='18px';
		};
	}
	
	/*首页视频列表链接点击后播放*/
	$('.vedio_list ul li a').click(function() {
		$(".vedio_main").css("width","100%");
	});
	
	/*选项卡脚本*/
	$(".post_collection_top li").click(function() {
		for(var i=1;i<6;i++){
			$("#tab_" + i).css("display","none");
			$(".post_collection_top li[class='current']").removeClass('current');
		}
		$(this).addClass('current');
		$("#tab_" + parseInt($(this).attr('rel'))).fadeIn(300);
		
	});
	
	//导航链接跳转新窗口
	//$("#menu a").attr("target","_blank");
	//移除category loop特色图title
	
	//导航菜单高亮
	$("li[class*='current-menu-item']").append('<span></span>');
	$("li[class*='current-menu-parent']").append('<span></span>');
	
	$('.l_imgbox img').removeAttr("title");
    //网页上部显示分页栏
	if($('.pagination')!=null){
		$('.pagination').clone(true).insertBefore($('.cool-post-box').eq(0));
	}
	//相册页左边Top排行榜偶数行背景色
	$('dd:odd').css("background", "#EFEFEF");
	//特色图片移上去变淡
	$('.post-img').hover(function() {
		$(this).find("img").stop().fadeTo('fast', 0.7);
	}, function() {
		$(this).find("img").stop().fadeTo('fast', 1);
	});
	//侧边栏幻灯片默认第一个被选中赋予默认样式
	jQuery("#imgBox ul li").eq(0).addClass("current");
	$("#nav li li").has('ul').children("a").append(" &raquo;");
	$("#nav li").has('ul').hover(function() {
		$(this).children("ul").slideDown(200);
	}, function() {
		$(this).children("ul").slideUp(200);
	});
	
	
	//一些后来添加的链接颜色渐变
	$('h2 a,.single_relations ul a,.single_random ul a,.l_text a').hover(
			function() {
				$(this).stop().animate({
					color : '#000'
				}, 200)
			}, function() {
				$(this).stop().animate({
					color : '#464646'
				}, 200)
			});
	//已经失效
	$('.post-img').hover(
			function() {
				$(this).find("div[class='wenzi']").css("opacity", "0.7").stop()
						.animate({
							marginTop : '-34px'
						}, 300);
				// $(this).find("div[class='wenzi']").stop().fadeTo('fast',0.7);
			}, function() {
				$(this).find("div[class='wenzi']").stop().animate({
					marginTop : '2px'
				}, 300);
			});
	//友情链接颜色渐变
	$('#link li a,#foot p a').hover(function() {
		$(this).stop().animate({
			color : '#f53b24'
		}, 200);
	}, function() {
		$(this).stop().animate({
			color : '#3c3c3c'
		}, 200);
	});
	//首页伸缩广告关闭与打开
	$('#playbtn').click(function() {
		$("#slide").stop().animate({
			height : "500px"
		}, 2000);
		$('#closebtn').css('display', 'block');
		$(this).css('display', 'none');
	});
	$('#closebtn').click(function() {
		$("#slide").stop().animate({
			height : "0px"
		}, 2000);
		$('#playbtn').css('display', 'block');
		$(this).css('display', 'none');
	});
	//控制伸缩广告初始化
	$(window).load(function() {
		$('#closebtn').css('display', 'block');
		var timeoutProcess = setTimeout(function() {
			$("#slide").stop().animate({
				height : "500px"
			}, 3000, function() {
				clearTimeout(timeoutProcess);
				$("#slide_space_ad").css('display', 'block');
				$("#slide").delay(2000).animate({
					height : "0px"
				}, 3000, function() {
					$('#closebtn').css('display', 'none');
					$('#playbtn').css('display', 'block');
				});

			});

		}, 2000);

	});
	//改变特色图片大小
	$(".post-img").find("img").css({
		width : "150px",
		height : "105px",
		float : "left"
	});
	//已经失效
	$("#demo .post-img").find("img").css({
		width : "150px",
		height : "210px",
		float : "left"
	});
	//主题自带侧边栏下载主题栏
	$('a.modalLink').click(
			function(e) {
				e.preventDefault();
				var id = $(this).attr('href');
				activeWindow = $('.window#' + id).css('opacity', '0').css(
						'top', '50%').css('left', '50%').fadeTo(500, 1);

				$('#modal').append('<div id="blind" />').find('#blind').css(
						'opacity', '0').fadeTo(500, 0.8).click(function(e) {
					closeModal();
				});
			});
	$('a.close').click(function(e) {
		e.preventDefault();
		closeModal();
	});
	function closeModal() {
		activeWindow.fadeOut(250, function() {
			$(this).css('top', '-1000px').css('left', '-1000px');
		});
		$('#blind').fadeOut(250, function() {
			$(this).remove();
		});
	}
	//假装异步加载
	$('.cool-post-title a').click(function() {
		$(this).html("正在加载中....");
	});
	$('.cool-read a').click(function() {
		$(this).parent().parent().find('.cool-post-title a').html("正在加载中....");
	});
	//添加一些title提示
	$("a[rel='tag']").attr("title", "点击查看此标签下的所有亮点");
	jQuery("#imgBox ul li img").eq(0).addClass("current");
	var url = jQuery("#imgBox ul li img").eq(
			$("#imgNum ul li span.current").index("#imgNum ul li span"))
			.parent().attr("href");
	jQuery(".imgTitle").html(
			"<a href='"
					+ url
					+ "'>"
					+ jQuery("#imgBox ul li img").eq(
							$("#imgNum ul li span.current").index(
									"#imgNum ul li span")).attr("title")
					+ "</a>");
	slide();
	//侧边栏幻灯片控制选项，谨慎修改
	$("#imgNum ul li span").click(
			function() {
				clearInterval(movepic);
				$("#imgNum ul li span").removeClass("current");
				$(this).addClass("current");
				$("#imgBox ul li").animate({
					'opacity' : '0'
				}, 700).removeClass("current");
				$("#imgBox ul li").eq(
						$("#imgNum ul li span.current").index(
								"#imgNum ul li span")).animate({
					'opacity' : '1'
				}, 700, function() {
				}).addClass("current");
				var url = jQuery("#imgBox ul li img").eq(
						$("#imgNum ul li span.current").index(
								"#imgNum ul li span")).parent().attr("href");
				jQuery(".imgTitle").html(
						"<a href='"
								+ url
								+ "'>"
								+ jQuery("#imgBox ul li img").eq(
										$("#imgNum ul li span.current").index(
												"#imgNum ul li span")).attr(
										"title") + "</a>");

				movepic = setInterval(function() {
					var nowpic = $("#imgNum ul li span.current").index(
							"#imgNum ul li span"), nextpic = nowpic + 1;
					if (nowpic == maxNum) {
						nextpic = 0;
					}
					fadePic(nowpic, nextpic);
				}, 3000);

			});

	/*--------------TAB选项卡脚本-------------*/
	$("#explore-nav li a").hover(function() {
		var curList = $("#explore-nav li a.current").attr("rel");
		var $newList = $(this);
		var curListHeight = $("#all-list-wrap").height();
		$("#all-list-wrap").height(curListHeight);
		$("#explore-nav li a").removeClass("current");
		$newList.addClass("current");
		var listID = $newList.attr("rel");
		if (listID != curList) {
			$("#" + curList).fadeOut(300, function() {
				$("#" + listID).fadeIn();
				var newHeight = $("#" + listID).height();
				$("#all-list-wrap").animate({
					height : newHeight
				});

			});
		}
		return false;
	});

	/*--------------聚光灯提示脚本-------------*/
	$(".activeUsers li").each(function() {
		$("a strong", this).css("opacity", "0");
	});
	$(".activeUsers li").hover(function() { // 悬浮
		$(this).stop().fadeTo(500, 1).siblings().stop().fadeTo(500, 0.2);
		$("a strong", this).stop().animate({
			opacity : 1,
			top : "-10px"
		}, 300);
	}, function() { // 寻出
		$(this).stop().fadeTo(500, 1).siblings().stop().fadeTo(500, 1);
		$("a strong", this).stop().animate({
			opacity : 0,
			top : "-1px"
		}, 300);
	});

	/*--------------修改评论模板的cite标签-------------*/
	// $("cite").wrapAll(document.createElement("div"));
	var citeLength = jQuery("cite").length;
	for ( var i = 0; i < citeLength; i++) {
		var citeText = jQuery("cite").eq(i).html();
		jQuery("cite").eq(i).after(
				jQuery("<div class='comment_author_title'></div>").html(
						citeText));
		jQuery("cite").eq(i).hide();
	}
});
/*侧边滚动栏*/
SidebarFollow = function() {

this.config = {
element: null, // 处理的节点
distanceToTop: 0 // 节点上边到页面顶部的距离
};

this.cache = {
originalToTop: 0, // 原本到页面顶部的距离
prevElement: null, // 上一个节点
parentToTop: 0, // 父节点的上边到顶部距离
placeholder: jQuery('<div>') // 占位节点
}
};

SidebarFollow.prototype = {

init: function(config) {
this.config = config || this.config;
var _self = this;
var element = jQuery(_self.config.element);

// 如果没有找到节点, 不进行处理
if(element.length <= 0) {
return;
}

// 获取上一个节点
var prevElement = element.prev();
while(prevElement.is(':hidden')) {
prevElement = prevElement.prev();
if(prevElement.length <= 0) {
break;
}
}
_self.cache.prevElement = prevElement;

// 计算父节点的上边到顶部距离
var parent = element.parent();
var parentToTop = parent.offset().top;
var parentBorderTop = parent.css('border-top');
var parentPaddingTop = parent.css('padding-top');
_self.cache.parentToTop = parentToTop + parentBorderTop + parentPaddingTop;

// 滚动屏幕
jQuery(window).scroll(function() {
_self._scrollScreen({element:element, _self:_self});
});

// 改变屏幕尺寸
jQuery(window).resize(function() {
_self._scrollScreen({element:element, _self:_self});
});
},

/**
* 修改节点位置
*/
_scrollScreen: function(args) {
var _self = args._self;
var element = args.element;
var prevElement = _self.cache.prevElement;

// 获得到顶部的距离
var toTop = _self.config.distanceToTop;

// 如果 body 有 top 属性, 消除这些位移
var bodyToTop = parseInt(jQuery('body').css('top'), 10);
if(!isNaN(bodyToTop)) {
toTop += bodyToTop;
}

// 获得到顶部的绝对距离
var elementToTop = element.offset().top - toTop;

// 如果存在上一个节点, 获得到上一个节点的距离; 否则计算到父节点顶部的距离
var referenceToTop = 0;
if(prevElement && prevElement.length === 1) {
referenceToTop = prevElement.offset().top + prevElement.outerHeight();
} else {
referenceToTop = _self.cache.parentToTop - toTop;
}

// 当节点进入跟随区域, 跟随滚动
if(jQuery(document).scrollTop() > elementToTop) {
// 添加占位节点
var elementHeight = element.outerHeight();
_self.cache.placeholder.css('height', elementHeight).insertBefore(element);
// 记录原位置
_self.cache.originalToTop = elementToTop;
// 修改样式
element.css({
top: toTop + 'px',
position: 'fixed'
});

// 否则回到原位
} else if(_self.cache.originalToTop > elementToTop || referenceToTop > elementToTop) {
// 删除占位节点
_self.cache.placeholder.remove();
// 修改样式
element.css({
position: 'static'
});
}
}
};