<?php
/*
Template Name: guestbook
*/
?>
<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
	<div class="s_position">
		<a href="<?php bloginfo('url'); ?>">首页</a>>>留言板
	</div>
	<div class="post-box">
		
		<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
		<?php endwhile; ?>
		<div class="post_content">
			<?php the_content(); ?>
		</div>
		<div class="comments-template">
			<?php comments_template(); ?>
		</div>
	</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
