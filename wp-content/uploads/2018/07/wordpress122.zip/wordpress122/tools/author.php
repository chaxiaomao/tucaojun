<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div class="author_panel">
	<div class="widget">
		<h2>名片</h2>
		<div class="author_img">
			<img src="<?php echo $options['author_image'];?>" width="150" height="200"/>
		</div>	
		<div class="author_desc">
			<ul>
				<li><span class="author_title">姓名 </span><?php echo $options['author_name'];?></li>
				<li><span class="author_title">工作 </span><?php echo $options['author_job'];?></li>
				<li><span class="author_title">电话 </span><?php echo $options['author_phone'];?></li>
				<li><span class="author_title">爱好 </span><?php echo $options['author_fun'];?></li>
			</ul>
		</div>	
	</div>
</div>
