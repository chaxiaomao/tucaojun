<!-- 近期评论 -->
<div class="widget-wrap">
	<div class="widget widget_recent_comments"><h2>近期评论</h2>
		<ul id="recentcomments">
			<?php 
				global $wpdb;
				$limit_num = '6'; 
				$my_email = "'" . get_bloginfo ('admin_email') . "'"; 
				$rc_comms = $wpdb->get_results("
				 SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
				 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
				 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
				 WHERE comment_approved = '1'
				 AND comment_type = ''
				 AND post_password = ''
				
				 ORDER BY comment_date_gmt
				 DESC LIMIT $limit_num
				 ");
				$rc_comments = '';
				foreach ($rc_comms as $rc_comm) { //get_avatar($rc_comm,$size='50')
				$rc_comments .= "<li class='widget_c_li'>". get_avatar($rc_comm,$size='50') ."<span class='comment-au'>" . $rc_comm->comment_author . "</span>说<br/><a href='"
				. get_permalink($rc_comm->ID) . "#comment-" . $rc_comm->comment_ID
				//. htmlspecialchars(get_comment_link( $rc_comm->comment_ID, array('type' => 'comment'))) 
				. "' title='发表在 " . $rc_comm->post_title . "'>" . strip_tags($rc_comm->comment_content)
				. "</a></li>\n";
				}
				$rc_comments = convert_smilies($rc_comments);
				echo $rc_comments;
			?>
		</ul>
	</div>
</div>