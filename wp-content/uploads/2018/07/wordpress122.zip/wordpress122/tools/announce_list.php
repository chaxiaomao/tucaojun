<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div class="author_panel">
	<div class="widget">
		<h2>滚动公告</h2>
		    	<ul class="slider" id="slider" style="top: 0px;">
	 <?php
        $loop = new WP_Query( array( 'post_type' => 'bulletin', 'posts_per_page' => 4 ) );
		$list_number=1;
        while ( $loop->have_posts() ) : $loop->the_post();
    ?>
        <li><span class="album_list"><?php echo $list_number;?></span><a href="<?php 
			$url = the_permalink();
			$url = substr($url,0,stristr($url,"/"));
			echo $url;
			$list_number++;
		?>" title="查看 <?php the_title(); ?>"><?php the_title(); ?></a></li>
        <?php endwhile; ?>
	</ul>
	<script type="text/javascript">
		new slider({id:'slider'})
	</script>
	</div>
</div>
