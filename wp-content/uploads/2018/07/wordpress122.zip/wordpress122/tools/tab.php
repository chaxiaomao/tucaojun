<!-- 选项卡 -->
<div id="organic-tabs">
	<ul id="explore-nav">
		<li id="ex-featured"><a rel="featured" href="#" class="current">最新发布</a></li>
		<li id="ex-core"><a rel="core" href="#">随机浏览</a></li>
		<li id="ex-jquery"><a rel="jquerytuts" href="#">热门文章</a></li>
	</ul>
	
	<div id="all-list-wrap" style="overflow:hidden">
	
		<ul id="featured">
			<?php $post_query = new WP_Query('showposts=10');
			while ($post_query->have_posts()) : $post_query->the_post();
			$do_not_duplicate = $post->ID; ?>
			<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
			<?php endwhile;?>
		</ul>
		 
		 <ul id="core">
			<?php
				global $post;
				$postid = $post->ID;
				$args = array( 'orderby' => 'rand', 'post__not_in' => array($post->ID), 'showposts' => 6);
				$query_posts = new WP_Query();
				$query_posts->query($args);
				?>
				<?php while ($query_posts->have_posts()) : $query_posts->the_post(); ?>
				<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
				<?php endwhile; ?>
		 </ul>
		 
		 <ul id="jquerytuts">
			<?php global $wpdb;$result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 10");  
				 foreach ($result as $post) {
				 setup_postdata($post);
				 $postid = $post->ID;
				 $title = $post->post_title;
				 $commentcount = $post->comment_count;
				 if ($commentcount != 0) { ?>
				 <li><a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>">
				 <?php echo $title ?></a> (+<?php echo $commentcount?>°)</li>
				 <?php } } ?>
		 </ul>
	 
	</div> 
 
</div>