<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div class="widget-wrap">
	<div class="widget">
		<h2>联系我</h2>
		<div class="share">
			<li class="qq"><a target="_blank" rel="nofollow" title="点击发起和我的QQ聊天" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $options['qq'];?>&site=qq&menu=yes"></a></li>
			<li class="t_qq"><a target="_blank" rel="nofollow" title="访问我的腾讯微博" href="<?php echo $options['t_qq'];?>"></a></li>
			<li class="rss"><a target="_blank" rel="nofollow" title="订阅我" href="<?php echo $options['rss'];?>"></a></li>
			<li class="weibo"><a target="_blank" rel="nofollow" title="访问我的新浪微博" href="<?php echo $options['sina'];?>"></a></li>
			<li>联系我</li>
		</div>
	</div>
</div>
