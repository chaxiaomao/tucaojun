<!-- 活跃读者 -->
<div class="widget-wrap">
	<div class="widget widget"><h2>活跃读者</h2>
		<ul class="activeUsers">
			<?php 
				global $wpdb;
				$limit_num = '12'; 
				$my_email = "'" . get_bloginfo ('admin_email') . "'"; 
				$rc_comms = $wpdb->get_results("
				 SELECT distinct comment_author, ID, post_title, comment_ID, comment_author_url , comment_author_email, comment_content
				 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
				 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
				 WHERE comment_approved = '1'
				 AND comment_type = ''
				 AND post_password = ''
				 group by comment_author
				 ORDER BY comment_date_gmt

				 DESC LIMIT $limit_num
				 ");
				$rc_comments = '';
				foreach ($rc_comms as $rc_comm) { //get_avatar($rc_comm,$size='50')
				$rc_comments .= "<li><a href='".$rc_comm->comment_author_url."'>".get_avatar($rc_comm,$size='50') ."<strong style='opacity: 0;'>". $rc_comm->comment_author." </strong></a></li>";
				}
				$rc_comments = convert_smilies($rc_comments);
				echo $rc_comments;
			?>
		</ul>
	</div>
</div>