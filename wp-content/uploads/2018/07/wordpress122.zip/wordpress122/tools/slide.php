<!-- 幻灯片 -->
<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php 
	$cateId = $options['slide_id'];
	$cateNum =$options['slide_num'];
?>
<div class="widget-wrap">
	<div class="widget">
		<div class="imgTitle"></div>
		<div id="imgBox">
			
			<?php 
				query_posts("showposts=".$options['slide_num']."&cat=".$cateId)?>
			<ul>
				<?php while (have_posts()) : the_post(); ?>
				<li>
					<?php if ( has_post_thumbnail() ) { ?>

					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_post_thumbnail(array(310,250),array(
	
						'title'	=> get_the_title(),
					)); ?></a>
					<?php } else {?>
					<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><img src="<?php bloginfo('template_url'); ?>/images/<?php echo rand(1,6)?>.jpg"  width="310" height="250" title="<?php the_title(); ?>"/></a>
					<?php } ?>
				</li>
				<?php endwhile; ?>
				
			</ul>
		</div>
		<div id="imgNum">
			<ul>
				<?php for($i=0;$i<$cateNum;$i++){
					if($i==0){
				?>
				<li>
					<span class="current"></span>
				</li>
				<?php
					}else{
				?>
				<li>
					<span></span>
				</li>
				<?php
					}
				} ?>
				
			</ul>
		</div>
	</div>
</div>