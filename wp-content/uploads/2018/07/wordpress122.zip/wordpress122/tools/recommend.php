<!-- 置顶文章 -->
<div class="widget-wrap">
	<div class="widget widget"><h2>置顶文章</h2>
		<ul>
			<?php
		//调用置顶文章,当没有置顶文章的时候显示最新5篇文章
		$sticky = get_option('sticky_posts');
		rsort( $sticky );
		$sticky = array_slice( $sticky, 0, 10);
		query_posts( array( 'post__in' => $sticky, 'caller_get_posts' => 1 ) );
		if (have_posts()) :
		while (have_posts()) : the_post();
		?>
		<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></li>
		<?php endwhile; endif; ?>
		</ul>
	</div>
</div>