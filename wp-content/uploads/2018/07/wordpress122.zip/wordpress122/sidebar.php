<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div id="sidebar">
 <?php
		if (is_category()):
		if (!dynamic_sidebar('category_sidebar')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
	 <?php
		if (is_tag()):
		if (!dynamic_sidebar('tag_sidebar')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
	 <?php
		if (is_day()||is_month()||is_year()||is_author()):
		if (!dynamic_sidebar('author_sidebar')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
	<?php
		if (is_page()):
		if (!dynamic_sidebar('sidebar-3')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
	 <?php
		if (is_single()):
		if (!dynamic_sidebar('sidebar-2')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
	 <?php
		if (is_home()):
		if (!dynamic_sidebar('sidebar-1')) : ?>
		<?php endif; ?>
		<?php if (!dynamic_sidebar('scroll_sidebar')) : ?>
		<?php endif; ?>
	 <?php endif; ?>
</div>
<!--sidebar结束-->
<script>
/* <![CDATA[ */
(new SidebarFollow()).init({
	element: jQuery('#scroll_sidebar'),
	distanceToTop: 15
});
/* ]]> */
</script>
