<?php




//主题设置初始化
function dwlxjz_settings_init(){
	//注册功能
	register_setting( 'dwlxjz_settings', 'AesRoom_theme_settings' );
}

//菜单
//添加控制页
function dwlxjz_add_settings_page() {
add_menu_page( __( 'AesRoom Theme' ), __( '主题设置' ), 'manage_options', 'dwlxjz-settings', 'dwlxjz_theme_settings_page');
}

add_action( 'admin_init', 'dwlxjz_settings_init' );
add_action( 'admin_menu', 'dwlxjz_add_settings_page' );

//选项
$categories = get_categories('hide_empty=0&orderby=name');
$wp_cats = array();
foreach ($categories as $category_list ) {
$wp_cats[$category_list->cat_ID] = $category_list->cat_name;
}
array_unshift($wp_cats, "Choose a category"); 
function dwlxjz_theme_settings_page() {

global $wp_cats, $color_schemes;
if ( ! isset( $_REQUEST['updated'] ) )
//request-请求
$_REQUEST['updated'] = false;
?>

<div class="wrap">
<div id="icon-options-general" class="icon32"></div><h2><span style="color:#555;">AesRoom</span>主题设置面板</h2>

<div id="panel-content">
<?php if ( false !== $_REQUEST['updated'] ) : ?>
<div class="updated fade"><p><strong><?php _e( 'Options saved' ); ?></strong></p></div>
<?php endif; ?>
<form method="post" action="options.php">

<?php settings_fields( 'dwlxjz_settings' ); ?>
<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php
$update=$_GET['settings-updated'];
if($update){
	echo "<div class='updated fade' style='margin:0 10px' id='message'><p style='color:green'><strong>主题设置成功</strong></p></div>";
}
?>

<div class="admin_bar">
<a href="#" class="control_title">作者介绍</a>
<div class="control_box">
访问我的网站:<a href='http://www.dwlxjz.com/'>远翔博客</a>
</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">是否移除作者链接</a>
	<div class="control_box">
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[keep_link]" style="color:#21759B;font-weight:bold">是否去掉底部的作者链接？您可以去掉我的链接，我不勉强</label><input id="AesRoom_theme_settings[keep_link]" name="AesRoom_theme_settings[keep_link]" type="checkbox" value="1" <?php checked( '1', $options['keep_link'] ); ?> />
	</div>
</div>

<!--
<div class="admin_bar">
<a href="#" class="control_title">背景色设置</a>
	<div class="control_box">
		<div class="form-item"><label for="color">Color:</label>
			<input id="color" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[bgColor]" value="#<?php esc_attr_e( $options['bgColor'] ); ?>" />
		</div><div id="picker"></div>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">首页幻灯片设置</a>
	<div class="control_box">
		<label class="description abouttxtdescription" for="AesRoom_theme_settings[show_home_slider]" style="color:#21759B;font-weight:bold">是否显示幻灯片轮播在首页</label><input id="AesRoom_theme_settings[show_home_slider]" name="AesRoom_theme_settings[show_home_slider]" type="checkbox" value="1" <?php checked( '1', $options['show_home_slider'] ); ?> />
		<br>
		<input id="AesRoom_theme_settings[slide_value]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_value]" value="<?php esc_attr_e( $options['slide_value'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_value]" style="color:#21759B;font-weight:bold"><?php _e( '【图片地址】' ); ?></label>
		<br>
		<input id="AesRoom_theme_settings[slide_value]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_value]" value="<?php esc_attr_e( $options['slide_value'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_value]" style="color:#21759B;font-weight:bold"><?php _e( '【图片地址】' ); ?></label>
		<br>
		<input id="AesRoom_theme_settings[slide_value]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_value]" value="<?php esc_attr_e( $options['slide_value'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_value]" style="color:#21759B;font-weight:bold"><?php _e( '【图片地址】' ); ?></label>
		<br>
		<input id="AesRoom_theme_settings[slide_value]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_value]" value="<?php esc_attr_e( $options['slide_value'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_value]" style="color:#21759B;font-weight:bold"><?php _e( '【图片地址】' ); ?></label>
	</div>
</div>
-->
<!--
<div class="admin_bar">
<a href="#" class="control_title">经典风格开关</a>
	<div class="control_box"><label class="description abouttxtdescription" for="AesRoom_theme_settings[show_classic]" style="color:#21759B;font-weight:bold">选择后将还原文章列表显示为原2.1版本的风格</label><input id="AesRoom_theme_settings[show_classic]" name="AesRoom_theme_settings[show_classic]" type="checkbox" value="1" <?php checked( '1', $options['show_classic'] ); ?> />
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">风格设置</a>
	<div class="control_box">
	<br/><label class="description abouttxtdescription" for="AesRoom_theme_settings[cat_1]" style="color:#21759B;font-weight:bold">请选择一个分类</label>
	<select name="AesRoom_theme_settings[cat_1]">
<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
<option value="<?php echo $cat_id;?>" <?php if ($options['cat_1'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
<?php } ?>
</select>
<select name="AesRoom_theme_settings[cat_2]">
<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
<option value="<?php echo $cat_id;?>" <?php if ($options['cat_2'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
<?php } ?>
</select>
<select name="AesRoom_theme_settings[cat_3]">
<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
<option value="<?php echo $cat_id;?>" <?php if ($options['cat_3'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
<?php } ?>
</select>
<select name="AesRoom_theme_settings[cat_4]">
<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
<option value="<?php echo $cat_id;?>" <?php if ($options['cat_4'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
<?php } ?>
</select>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">网站皮肤设置</a>
	<div class="control_box"><label class="description abouttxtdescription" for="AesRoom_theme_settings[skin]" style="color:#21759B;font-weight:bold">选择您喜欢的皮肤</label>
	<select name="AesRoom_theme_settings[skin]">
		<option value="<?php echo 'black';?>" <?php if ($options['skin'] == 'black'){ echo 'selected="selected"'; } ?>>炫酷黑</option>
		<option value="<?php echo 'purple';?>" <?php if ($options['skin'] == 'purple'){ echo 'selected="selected"'; } ?>>熏衣紫</option>
		<option value="<?php echo 'blue';?>" <?php if ($options['skin'] == 'blue'||$options['skin']==""){ echo 'selected="selected"'; } ?>>碧日蓝</option>
		<option value="<?php echo 'red';?>" <?php if ($options['skin'] == 'red'){ echo 'selected="selected"'; } ?>>海棠红</option>
		<option value="<?php echo 'gray';?>" <?php if ($options['skin'] == 'gray'){ echo 'selected="selected"'; } ?>>科技灰</option>
	</select>
	</div>
</div>
-->

<div class="admin_bar">
<a href="#" class="control_title">回复表情设置</a>
	<div class="control_box"><label class="description abouttxtdescription" for="AesRoom_theme_settings[smile]" style="color:#21759B;font-weight:bold">选择您喜欢的表情</label>
	<select name="AesRoom_theme_settings[smile]">
		<option value="<?php echo 'android';?>" <?php if ($options['smile'] == 'android'){ echo 'selected="selected"'; } ?>>安卓表情</option>
		<option value="<?php echo 'comcom';?>" <?php if ($options['smile'] == 'comcom'){ echo 'selected="selected"'; } ?>>可爱表情</option>
		<option value="<?php echo 'qq_1';?>" <?php if ($options['smile'] == 'qq_1'){ echo 'selected="selected"'; } ?>>QQ方脸</option>
		<option value="<?php echo 'riceball';?>" <?php if ($options['smile'] == 'riceball'){ echo 'selected="selected"'; } ?>>清新表情</option>
		<option value="<?php echo 'qq_2';?>" <?php if ($options['smile'] == 'qq_2'||$options['smile']==""){ echo 'selected="selected"'; } ?>>QQ圆脸</option>
		<option value="<?php echo 'renren';?>" <?php if ($options['smile'] == 'renren'){ echo 'selected="selected"'; } ?>>人人表情</option>
	</select>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">Favicon图标设置</a>
	<div class="control_box"><input id="AesRoom_theme_settings[upload_favicon]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[upload_favicon]" value="<?php esc_attr_e( $options['upload_favicon'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[upload_favicon]" style="color:#21759B;font-weight:bold">网站的标志，.ico后缀的图片</label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">背景图片设置</a>
	<div class="control_box"><input id="AesRoom_theme_settings[bg]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[bg]" value="<?php esc_attr_e( $options['bg'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[bg]" style="color:#21759B;font-weight:bold">请确保您的背景图片重复显示能完美拼合</label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">伸缩式广告设置</a>
	<div class="control_box">
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[slide]" style="color:#21759B;font-weight:bold"><?php _e( '【是否显示伸缩式广告(1060*500像素)】' ); ?></label><input id="AesRoom_theme_settings[slide]" name="AesRoom_theme_settings[slide]" type="checkbox" value="1" <?php checked( '1', $options['slide'] ); ?> />
	<br>
	<input id="AesRoom_theme_settings[slide_value]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_value]" value="<?php esc_attr_e( $options['slide_value'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_value]" style="color:#21759B;font-weight:bold"><?php _e( '【图片地址】' ); ?></label>
	<br>
	<input id="AesRoom_theme_settings[slide_href]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_href]" value="<?php esc_attr_e( $options['slide_href'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_href]" style="color:#21759B;font-weight:bold"><?php _e( '【链接地址，不要忘了http://】' ); ?></label>
	<br>
	<input id="AesRoom_theme_settings[slide_space]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_space]" value="<?php esc_attr_e( $options['slide_space'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_space]" style="color:#21759B;font-weight:bold"><?php _e( '【缩回去以后显示的图片地址】' ); ?></label>
	<br>
	<input id="AesRoom_theme_settings[slide_space_href]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[slide_space_href]" value="<?php esc_attr_e( $options['slide_space_href'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_space_href]" style="color:#21759B;font-weight:bold"><?php _e( '【缩回去以后图片链接地址，不要忘了http://】' ); ?></label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">站长名片设置</a>
	<div class="control_box">
	头像:<input id="AesRoom_theme_settings[author_image]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[author_image]" value="<?php esc_attr_e( $options['author_image'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[author_image]" style="color:#21759B;font-weight:bold"><?php _e( '【150*200像素】' ); ?></label>
	<br/>
	姓名:<input id="AesRoom_theme_settings[author_name]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[author_name]" value="<?php esc_attr_e( $options['author_name'] ); ?>" />
	<br/>
	工作:<input id="AesRoom_theme_settings[author_job]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[author_job]" value="<?php esc_attr_e( $options['author_job'] ); ?>" />
	<br/>
	电话:<input id="AesRoom_theme_settings[author_phone]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[author_phone]" value="<?php esc_attr_e( $options['author_phone'] ); ?>" />
	<br/>
	爱好:<input id="AesRoom_theme_settings[author_fun]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[author_fun]" value="<?php esc_attr_e( $options['author_fun'] ); ?>" /><label class="description abouttxtdescription" for="AesRoom_theme_settings[author_fun]" style="color:#21759B;font-weight:bold"><?php _e( '【不要太长哦】' ); ?></label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">侧边栏设置</a>
	<div class="control_box">
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[changesidebar]" style="color:#21759B;font-weight:bold"><?php _e( '【侧边栏左右是否调换】' ); ?></label><input id="AesRoom_theme_settings[changesidebar]" name="AesRoom_theme_settings[changesidebar]" type="checkbox" value="1" <?php checked( '1', $options['changesidebar'] ); ?> />
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">文章页风格设置</a>
	<div class="control_box">
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[show_full]" style="color:#21759B;font-weight:bold">是否启用宽频</label><input id="AesRoom_theme_settings[show_full]" name="AesRoom_theme_settings[show_full]" type="checkbox" value="1" <?php checked( '1', $options['show_full'] ); ?> />
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">文章页广告设置</a>
	<div class="control_box">
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[article]" style="color:#21759B;font-weight:bold">是否显示广告[非宽屏风格]</label><input id="AesRoom_theme_settings[article]" name="AesRoom_theme_settings[article]" type="checkbox" value="1" <?php checked( '1', $options['article'] ); ?> />
	<br/>
	<textarea id="AesRoom_theme_settings[article_value]" class="regular-text upload_field"  name="AesRoom_theme_settings[article_value]"><?php esc_attr_e( $options['article_value'] ); ?></textarea>
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[article_value]" style="color:#21759B;font-weight:bold"><?php _e( '【200*200像素.】' ); ?></label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">社会化联系方式</a>
	<div class="control_box">QQ号码
	<input id="AesRoom_theme_settings[qq]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[qq]" value="<?php esc_attr_e( $options['qq'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[qq]" style="color:#21759B;font-weight:bold">QQ号码，便于直接发起聊天</label>
	<br/>

	新浪微博
<input id="AesRoom_theme_settings[sina]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[sina]" value="<?php esc_attr_e( $options['sina'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[sina]" style="color:#21759B;font-weight:bold">新浪微博地址</label>
	
<br/>
	腾讯微博
	<input id="AesRoom_theme_settings[t_qq]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[t_qq]" value="<?php esc_attr_e( $options['t_qq'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[t_qq]" style="color:#21759B;font-weight:bold">腾讯微博地址</label>
	
<br/>
	RSS订阅
	<input id="AesRoom_theme_settings[rss]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[rss]" value="<?php esc_attr_e( $options['rss'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[rss]" style="color:#21759B;font-weight:bold">RSS订阅</label>
	
	</div>
</div>
<div class="admin_bar">
<a href="#" class="control_title">网站LOGO设置</a>
	<div class="control_box"><input id="AesRoom_theme_settings[logo]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[logo]" value="<?php esc_attr_e( $options['logo'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[logo]" style="color:#21759B;font-weight:bold">230*35像素</label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">全局公告设置</a>
	<div class="control_box"><input id="AesRoom_theme_settings[announce]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[announce]" value="<?php esc_attr_e( $options['announce'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[announce]" style="color:#21759B;font-weight:bold">公告内容</label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">首页幻灯片设置</a>
	<div class="control_box">
		<label class="description abouttxtdescription" for="AesRoom_theme_settings[index_slide_id]" style="color:#21759B;font-weight:bold">选择调用栏目</label><select name="AesRoom_theme_settings[index_slide_id]">
		<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
		<option value="<?php echo $cat_id;?>" <?php if ($options['index_slide_id'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
		<?php } ?>
		</select>
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[index_slide_num]" style="color:#21759B;font-weight:bold">输入调用数量</label><input id="AesRoom_theme_settings[index_slide_num]"  type="text" size="10" name="AesRoom_theme_settings[index_slide_num]" value="<?php esc_attr_e( $options['index_slide_num'] ); ?>" />
	
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">侧边栏幻灯片设置</a>
	<div class="control_box">
		<label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_id]" style="color:#21759B;font-weight:bold">选择调用栏目</label><select name="AesRoom_theme_settings[slide_id]">
		<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
		<option value="<?php echo $cat_id;?>" <?php if ($options['slide_id'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
		<?php } ?>
		</select>
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[slide_num]" style="color:#21759B;font-weight:bold">输入调用数量</label><input id="AesRoom_theme_settings[slide_num]"  type="text" size="10" name="AesRoom_theme_settings[slide_num]" value="<?php esc_attr_e( $options['slide_num'] ); ?>" />
	
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">相册栏目设置</a>
	<div class="control_box"><label class="description abouttxtdescription" for="AesRoom_theme_settings[album_id]" style="color:#21759B;font-weight:bold">请选择调用栏目</label><select name="AesRoom_theme_settings[album_id]">
	<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
	<option value="<?php echo $cat_id;?>" <?php if ($options['album_id'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
	<?php } ?>
	</select>
	
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">视频栏目设置</a>
	<div class="control_box"><label class="description abouttxtdescription" for="AesRoom_theme_settings[vedio_id]" style="color:#21759B;font-weight:bold">请选择调用栏目</label><select name="AesRoom_theme_settings[vedio_id]">
	<?php $category_ids = get_all_category_ids();foreach ($category_ids as $cat_id) {$cat_name = get_cat_name($cat_id); ?>
	<option value="<?php echo $cat_id;?>" <?php if ($options['vedio_id'] == $cat_id ){ echo 'selected="selected"'; } ?>><?php echo htmlentities($cat_name,ENT_QUOTES,"UTF-8"); ?></option>
	<?php } ?>
	</select>
	
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">首页关键字</a>
	<div class="control_box"><input id="AesRoom_theme_settings[index_key]" class="regular-text upload_field" type="text" size="36" name="AesRoom_theme_settings[index_key]" value="<?php esc_attr_e( $options['index_key'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[index_key]" style="color:#21759B;font-weight:bold">首页关键字，区别于内容页面</label>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">随机图片调用设置</a>
	<div class="control_box"><input id="AesRoom_theme_settings[random_image]" class="regular-text upload_field" type="text" size="10" name="AesRoom_theme_settings[random_image]" value="<?php esc_attr_e( $options['random_image'] ); ?>" />
	<label class="description abouttxtdescription" for="AesRoom_theme_settings[random_image]" style="color:#21759B;font-weight:bold">确保有足够的图片，请输入整数</label>
	</div>
</div>


<div class="admin_bar">
<a href="#" class="control_title">首页描述设置</a>
	<div class="control_box">
		<textarea id="AesRoom_theme_settings[index_desc]" class="regular-text upload_field"  name="AesRoom_theme_settings[index_desc]"><?php esc_attr_e( $options['index_desc'] ); ?></textarea>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">网站优化设置[推荐]</a>
	<div class="control_box">
		<table>
		<?php
			$category_ids = get_all_category_ids();
			foreach($category_ids as $cat_id) {
				$cat_name = get_cat_name($cat_id);
			  echo  "<tr><td>".$cat_name.'['.$cat_id .']</td>';
			  ?>
			  <td><input id='AesRoom_theme_settings[<?php echo $cat_id ?>]' name='AesRoom_theme_settings[<?php echo $cat_id ?>]' value="<?php esc_attr_e($options[$cat_id]); ?>"/></td>
			  <td><input id='AesRoom_theme_settings[<?php echo $cat_name ?>]' name='AesRoom_theme_settings[<?php echo $cat_name ?>]' value="<?php esc_attr_e($options[$cat_name]); ?>"/></td>
			  <td style='color:#21759B;font-weight:bold'>关键字、描述</td>
			  </tr>
			<?php }
		?>
		</table>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">全新体验设置[推荐]</a>
	<div class="control_box">
		这里您将能看到所有的单页，分类页，首页，甚至于是文章页，现在，您可以自定义这些页面头部的显示文字，可以是链接，可以是公告，随意DIY。
		<table>
			<tr>
				<td>首页:</td>
				<td><textarea id="AesRoom_theme_settings[index_view]" class="regular-textarea upload_field"  name="AesRoom_theme_settings[index_view]"><?php esc_attr_e( $options['index_view']); ?></textarea></td>
		<?php
			$category_ids = get_all_category_ids();
			foreach($category_ids as $cat_id) {
				$cat_name = get_cat_name($cat_id);
			  echo  "<tr><td>分类:".$cat_name.'['.$cat_id .']</td>';
			  ?>
			  <td><textarea id="AesRoom_theme_settings[cat_<?php echo $cat_id;?>]" class="regular-textarea upload_field"  name="AesRoom_theme_settings[cat_<?php echo $cat_id;?>]"><?php esc_attr_e( $options['cat_'.$cat_id]); ?></textarea></td>
			  </tr>
			<?php }
		?>
		
		 
	 <?php
		  $pages = get_pages();
		  foreach ($pages as $pagg) {
			  $option = '<tr><td>页面:'."<a target='_blank' href='".get_page_link($pagg->ID)."'>".$pagg->post_title."</a>";
			  echo $option.'</td>';
			?>
			<td><textarea id="AesRoom_theme_settings[page_<?php echo $pagg->ID;?>]" class="regular-textarea upload_field"  name="AesRoom_theme_settings[page_<?php echo $pagg->ID;?>]"><?php esc_attr_e( $options['page_'.$pagg->ID]); ?></textarea></td>
			</tr>
		  <?php }
		 ?>
		 <?php query_posts( $query_string . '&posts_per_page=-1' );if (have_posts()) : while ( have_posts() ) : the_post();?>
			<tr>
				<td>文章:<?php the_title(); ?></td>
				<td><textarea id="AesRoom_theme_settings[post_<?php echo the_ID();?>]" class="regular-textarea upload_field"  name="AesRoom_theme_settings[post_<?php echo the_ID();?>]"><?php esc_attr_e( $options['post_'.get_the_ID()]); ?></textarea></td>
			</tr>
		 
		 <?php endwhile; ?>
		<?php endif; ?>
		 
		</table>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">版权信息</a>
	<div class="control_box">
		<textarea id="AesRoom_theme_settings[copyright]" class="regular-textarea upload_field"  name="AesRoom_theme_settings[copyright]"><?php esc_attr_e( $options['copyright'] ); ?></textarea>
	</div>
</div>

<div class="admin_bar">
<a href="#" class="control_title">统计代码</a>
	<div class="control_box">
		<textarea id="AesRoom_theme_settings[analytics]" class="regular-textarea upload_field"  name="AesRoom_theme_settings[analytics]"><?php esc_attr_e( $options['analytics'] ); ?></textarea>
	</div>
</div>
<br/>
<div class="admin_bar">
	<div class="admin_left"><input type="submit" class="button-primary" value="保存设置" /></div>
</div>
</form>
</div><!-- END wrap -->

<?php
	$themeurl = get_bloginfo('template_url');
	echo "<link type='text/css' rel='stylesheet' href='".$themeurl."/functions/functions.css'/><script type='text/javascript' src='".$themeurl."/js/jquery-1.6.min.js'></script><script type='text/javascript' src='".$themeurl."/functions/functions.js'></script><script type='text/javascript' charset='utf-8'>
  $(document).ready(function() {
    $('#demo').hide();
  });
 </script>";
}?>
