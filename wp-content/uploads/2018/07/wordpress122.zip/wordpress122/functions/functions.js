$(function()
{

$(".control_title").click(function(event) {
event.preventDefault();
$(this).parent().children(".control_box").slideToggle();
});
	var item_index = 1;
	$(".control_title").each(function() {
		var innerText = $(this).html();
		$(this).html("");
		$(this).append(item_index+"."+innerText);
		item_index = item_index+1;
	});
});
