<?php get_header(); ?>
<div class="s_position">
	<a href="<?php bloginfo('url'); ?>">首页</a>>><?php  echo the_title(); ?>
</div>
<div class="s_content">
<?php
	$loop = new WP_Query( array( 'post_type' => 'album', 'posts_per_page' => 4 ) );
	while ( $loop->have_posts() ) : $loop->the_post();
?>
	<div class="s_panel">
		<h2><?php echo the_title(); ?></h2>
		<div class="s_info">
			<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
		</div>
			<?php the_content(); ?>
	</div>

</div>
</div>
<?php endwhile; ?>
<?php include (TEMPLATEPATH . '/page-sidebar.php'); ?>
<?php get_footer(); ?>
