<?php get_header(); ?>
	<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
	<?php setPostViews(get_the_ID()); ?>
		<div class="single_content" width="width:1060px">
			<div class="single_header">
				<h1><?php the_title(); ?></h1>
				<div class="single_left">
					<p><span class="author">编辑 : <?php the_author(); ?></span></p>
					<p><span class="date">时间 : <?php the_time('Y-m-d H:i:s'); ?></span></p>
					<p><span class="view">浏览 : <?php echo getPostViews(get_the_ID()); ?></span></p>
					<?php if (get_the_tags()): ?><p><span class="tags">标签 : <?php the_tags('','&nbsp;'); ?></span></p><?php endif; ?>
					<!-- Baidu Button BEGIN -->
						<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
						<a class="bds_qzone"></a>
						<a class="bds_tsina"></a>
						<a class="bds_tqq"></a>
						<a class="bds_renren"></a>
						<a class="bds_t163"></a>
						<span class="bds_more"></span>
						<a class="shareCount"></a>
						</div>
						<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=0" ></script>
						<script type="text/javascript" id="bdshell_js"></script>
						<script type="text/javascript">
						document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
						</script>
						<!-- Baidu Button END -->
				</div>
				<div class="single_right">
					<?php if ( has_post_thumbnail() ) { ?>
						<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?> 链接:"><?php the_post_thumbnail(); ?></a>
					<?php }?>
				</div>
			</div>
			
			<!-- 正文部分 -->
			<div class="single_core">
				<div class="content_core"><?php the_content(); ?></div>
				<script type="text/javascript">
					$(".gallery").galleria();
				</script>
				<?php if (comments_open()) comments_template( '', true ); ?>
			</div>
			
		</div>
		<div style="display:none" id="prev_link">
		<?php if (get_previous_post()) { 
								previous_post_link('%link');
								} else {
								echo "end";
							} ?>
		</div>
		<div style="display:none" id="next_link">
		<?php if (get_next_post()) {
								next_post_link('%link');
								} else {
								  echo "end";
								}?>
		</div>
	<?php endwhile; ?>
	<!-- 文章翻页 -->
	<a href="#" title='下一篇' id="next_a" rel="<?php the_ID(); ?>"><span>›</span></a>
	<a href="#" title='上一篇' id="prev_a" rel="<?php the_ID(); ?>"><span>‹</span></a>
<?php get_footer(); ?>
