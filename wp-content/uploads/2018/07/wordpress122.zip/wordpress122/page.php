<?php get_header(); ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
<?php setPostViews(get_the_ID()); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
	<div class="s_position">
		<a href="<?php bloginfo('url'); ?>">首页</a>>><?php  echo the_title(); ?>
	</div>
	<div class="s_content">
		<div class="s_panel">
			<h2><?php echo the_title(); ?></h2>
			<div class="s_info">
				<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
			</div>
				<?php the_content(); ?>
		</div>

	</div>
</div>
<?php endwhile; ?>
<?php include (TEMPLATEPATH . '/page-sidebar.php'); ?>
<?php get_footer(); ?>
