<?php
/*
Template Name: wall
*/
?>
<?php get_header(); ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
<?php setPostViews(get_the_ID()); ?>
<div id="content">
	<div class="s_position">
		<a href="<?php bloginfo('url'); ?>">首页</a>>><?php  echo the_title(); ?>
	</div>
	<div class="s_content">
		<div class="s_panel" id="tagPanel">
			<h2><?php echo the_title(); ?></h2>
			<div class="s_info">
				<?php edit_post_link( __('编辑页面'), '<span class="edit">', '</span>' ); ?>
			</div>
			<?php the_content(); ?>
				<ul class="activeUsers">
					<?php 
						$limit_num = '100'; 
						$my_email = "'" . get_bloginfo ('admin_email') . "'"; 
						$rc_comms = $wpdb->get_results("
						 SELECT distinct comment_author, ID, post_title, comment_ID, comment_author_url , comment_author_email, comment_content
						 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
						 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
						 WHERE comment_approved = '1'
						 AND comment_type = ''
						 AND post_password = ''
						 group by comment_author
						 ORDER BY comment_date_gmt

						 DESC LIMIT $limit_num
						 ");
						$rc_comments = '';
						foreach ($rc_comms as $rc_comm) { //get_avatar($rc_comm,$size='50')
						$rc_comments .= "<li><a href='".$rc_comm->comment_author_url."'>".get_avatar($rc_comm,$size='50') ."<strong style='opacity: 0;'>". $rc_comm->comment_author." </strong></a></li>";
						}
						$rc_comments = convert_smilies($rc_comments);
						echo $rc_comments;
					?>
				</ul>
		</div>
	</div>
</div>
<?php endwhile; ?>
<?php include (TEMPLATEPATH . '/page-sidebar.php'); ?>
<?php get_footer(); ?>
