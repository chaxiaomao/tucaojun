<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<div id="cool-footer">
	<div id="cool-link">
		<h3>友情链接</h3>
		<ul>
			<?php if ($options['keep_link']!=1){?>
				<a href="http://www.dwlxjz.com/">远翔博客</a>
			<?php }?>
			<?php wp_list_bookmarks('category_before=&category_after=&title_li=&categorize=0&show_name=0&show_description=0&between=: &show_updated=1'); ?>
		</ul>
	</div>
	<div id="cool-copyright">
		<?php echo $options['copyright']; ?>
	</div>
	<div id="cool-analytics">
		<?php echo $options['analytics']; ?>
	</div>
</div>
<div id="livetip"></div>
<div id="view_box"></div>
<div id="view_shadow"></div>
</body>
</html>