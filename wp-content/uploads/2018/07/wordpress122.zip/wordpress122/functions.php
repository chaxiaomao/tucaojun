<?php
/*
Theme Name: AesRoom
Theme URI: http://dwlxjz.com/
Author: dwlxjz
Author URI: http://dwlxjz.com/
Description:None
Version: 2.2
*/

include('functions/theme-admin.php');
$pageCount = 1;

/**
 * 无插件分页函数
 */
function pagination($query_string){   
	global $posts_per_page, $paged,$orderby;   
	$my_query = new WP_Query($query_string ."&posts_per_page=-1");   
	$total_posts = $my_query->post_count;   
	if(empty($paged))
		$paged = 1;   
	if(empty($orderby))
		$orderby = 'date';  
	$prev = $paged - 1;   
	$next = $paged + 1;   
	$range = 2; // only edit this if you want to show more page-links   
	$showitems = ($range * 2)+1;   
	  
	$pages = ceil($total_posts/$posts_per_page);  
	
	if(1 != $pages){   
		echo "<div class='pagination'>";   
		echo ($paged > 2 && $paged+$range+1 > $pages && $showitems < $pages)? "<a href='".get_pagenum_link(1)."#content'>最前</a>":"";   
		echo ($paged > 1 && $showitems < $pages)? "<a href='".get_pagenum_link($prev)."#content'>上一页</a>":"";   
		  
		for ($i=1; $i <= $pages; $i++){   
			if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){   
			echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."#content' class='inactive' >".$i."</a>";   
			}   
		}   
		echo ($paged < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($next)."?orderby=".$orderby."#content'>下一页</a>" :"";   
		echo ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) ? "<a href='".get_pagenum_link($pages)."#content'>最后</a>":"";   
		echo "</div>\n";   
	}   
	return $pages;
}  


/**
 * 注册侧边栏小工具
 */
if( function_exists('register_sidebar') ) {
    register_sidebar(array(
        'name' => '侧边栏',
		'id' => 'sidebar-1',
        'before_widget' => '<div class="widget-wrap"><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => '文章页侧边栏',
		'id' => 'sidebar-2',
        'before_widget' => '<div class="widget-wrap"><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => '单页侧边栏',
		'id' => 'sidebar-3',
        'before_widget' => '<div class="widget-wrap"><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => '侧边栏滚动层(仅可存一个小工具)',
		'id' => 'scroll_sidebar',
        'before_widget' => '<div class="widget-wrap" id="scroll_sidebar"><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => '分类页侧边栏',
		'id' => 'category_sidebar',
        'before_widget' => '<div class="widget-wrap" ><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => '标签页侧边栏',
		'id' => 'tag_sidebar',
        'before_widget' => '<div class="widget-wrap" ><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => '天，月，年，作者页面侧边栏',
		'id' => 'author_sidebar',
        'before_widget' => '<div class="widget-wrap" ><div class="widget %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
}

/**
 * 注册热门文章小工具
 */
class aesroom_hot extends WP_Widget{   
	function aesroom_hot(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带热门文章工具');   
		$this->WP_Widget( false,'AesRoom主题-热门文章工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/hotList.php");   
	}   
}

/**
 * 注册社会化小工具
 */
class aesroom_communicate extends WP_Widget{   
	function aesroom_communicate(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带社会化工具');   
		$this->WP_Widget( false,'AesRoom主题-社会化工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/communicate.php");   
	}   
}  

/**
 * 注册选项卡小工具
 */
class aesroom_tab extends WP_Widget{   
	function aesroom_tab(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带选项卡工具');   
		$this->WP_Widget( false,'AesRoom主题-选项卡工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/tab.php");   
	}   
}  

/**
 * 注册置顶文章小工具
 */
class aesroom_recommend extends WP_Widget{   
	function aesroom_recommend(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带置顶文章工具');   
		$this->WP_Widget( false,'AesRoom主题-置顶文章工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/recommend.php");   
	}   
}  

/**
 * 注册活跃度者小工具
 */
class aesroom_activeusers extends WP_Widget{   
	function aesroom_activeusers(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带活跃读者工具');   
		$this->WP_Widget( false,'AesRoom主题-活跃读者工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/activeusers.php");   
	}   
}  

/**
 * 注册幻灯片小工具
 */
class aesroom_slide extends WP_Widget{   
	function aesroom_slide(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带幻灯片工具');   
		$this->WP_Widget( false,'AesRoom主题-幻灯片工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/slide.php");   
	}   
}  

/**
 * 注册公告列表小工具
 */
class aesroom_announce extends WP_Widget{   
	function aesroom_announce(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带滚动公告工具');   
		$this->WP_Widget( false,'AesRoom主题-滚动公告工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/announce_list.php");   
	}   
}    

/**
 * 注册站长名片小工具
 */
class aesroom_author extends WP_Widget{   
	function aesroom_author(){   
		$widget_options = array('classname'=>'set_contact','description'=>'主题自带站长名片工具');   
		$this->WP_Widget( false,'AesRoom主题-站长名片工具',$widget_options );   
	}   
	function widget($instance){   
		include("tools/author.php");   
	}   
} 
 
/**
 * 注册自定义小工具到系统小工具栏
 */
add_action('widgets_init',create_function('', 'return register_widget("aesroom_hot");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_communicate");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_tab");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_recommend");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_activeusers");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_slide");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_announce");')); 
add_action('widgets_init',create_function('', 'return register_widget("aesroom_author");')); 

/*注册导航*/
register_nav_menus( array(
		'primary' => __( '选择主菜单', 'dwlxjz' ),
	) );

/*主题欢迎信息*/
function templateMessage($message, $errormsg )
{
	if ($errormsg) {
		echo '<div id="message" class="error">';
	}
	else {
		echo '<div id="message" class="updated fade">';
	}
	echo "<p style='color:green'><strong>$message</strong></p></div>";
} 

function load_post() {
	header('Content-type: text/json');
	// 如果 action ID 是 load_post, 并且传入的必须参数存在, 则执行响应方法
	if($_GET['action'] == 'load_post' && $_GET['id'] != '') {
		$id = $_GET["id"];
		$output = '';
 
		// 获取文章对象
		global $wpdb, $post;
		$post = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE ID = %d LIMIT 1", $id));
 
		// 如果指定 ID 的文章存在, 则对他进行格式化
		if($post) {
			$content = $post->post_content;
			$title = $post->post_title;
			$time = $post->post_date;
			$ids = $post->ID;
			$content = balanceTags($content);
			$output = wpautop($content);
		}
		$postinfo = array (
		"id"  => $ids,
	    "content"  => $content,
	    "title" => $title,
	    "time"   => $time
		);
		//echo "{'content':'".$output."'}";
	//echo str_replace('\\/', '/', preg_replace("#\\\u([0-9a-f]{4})#ie", "iconv('UCS-2BE', 'UTF-8', pack('H4', '\\1'))", json_encode($postinfo)));
	echo json_encode($postinfo);
		// 打印文章内容并中断后面的处理
		//echo $output;
		//echo $title;
		//echo $time;
		die();
	}
}
// 将接口加到 init 中
add_action('init', 'load_post');

function showAdminMessages()
{
    templateMessage("欢迎使用AesRoom主题2.2版，这是一款永久免费开源的wordpress主题，作者主页<a href='http://www.dwlxjz.com/'>点击访问</a>。加源码网站全新上线，有您喜欢的wordpress主题教程，<a href='http://www.jiacode.com/'>点击访问</a>.", false);
}
add_action('admin_notices', 'showAdminMessages');
	

/**
 * 文章排序
 */
function articlesOrder(){
	$b = get_bloginfo('url');
	$page = $paged==null?"":"&paged=".$paged;
	$cats = $cat==null?"":"&cat=".$cat;
	$tags = $tag==null?"":"&tag=".$tag;
	$day = $m==null?"":"&m=".$m;
	echo "<a href='".$b."?orderby=rand".$page.$cats.$tags.$day."#content' title='随即发现精彩'>随机</a>&nbsp;";
	echo "<a href='".$b."?orderby=hot".$page.$cats.$tags.$day."#content' title='看看哪些被围观'>热门</a>&nbsp;";
	echo "<a href='".$b."?orderby=date".$page.$cats.$tags.$day."#content' title='查看作者最近发表了什么'>时间</a>&nbsp;";
}	
	

/**
 * 获取浏览次数
 */
function getPostViews($postID){   
	$count_key = 'post_views_count';   
	$count = get_post_meta($postID, $count_key, true);   
	if($count==''){   
		delete_post_meta($postID, $count_key);   
		$initCount = 0;
		add_post_meta($postID, $count_key, $initCount);   
		return $initCount."次";   
	}   
	return $count.'次';   
}



/**
 * 设置浏览次数
 */
function setPostViews($postID) {   
	$count_key = 'post_views_count';   
	$count = get_post_meta($postID, $count_key, true);   
	if($count==''){   
		$initCount = 0;   
		delete_post_meta($postID, $count_key);   
		add_post_meta($postID, $count_key, $initCount);   
	}else{   
		$count++;   
		update_post_meta($postID, $count_key, $count);   
	}   
}  


//开启文章缩略图支持
add_theme_support( 'post-thumbnails' );

/**
 * 添加回复表情
 */
function wp_smilies() {
    global $wpsmiliestrans;
    if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;
    $smilies = array_unique($wpsmiliestrans);
    $link='';
    foreach ($smilies as $key => $smile) {
        $file = get_bloginfo('wpurl').'/wp-includes/images/smilies/'.$smile;
        $value = " ".$key." ";
        $img = "<img src=\"{$file}\" alt=\"{$smile}\" />";
        $imglink = htmlspecialchars($img);
        $link .= "<a href=\"#commentform\" title=\"{$smile}\" onclick=\"document.getElementById('comment').value += '{$value}'\">{$img}</a>&nbsp;";
    }
    echo '<div class="wp_smilies">'.$link.'</div>';
}

/**
 * 彩色标签云
 */
function colorCloud($text) {
	$text = preg_replace_callback('|<a (.+?)>|i', 'colorCloudCallback', $text);
	return$text;
}
function colorCloudCallback($matches) {
	$text = $matches[1];
	$color = dechex(rand(0,25507305));
	$pattern = '/style=(\'|\")(.*)(\'|\")/i';
	$text = preg_replace($pattern, "style=\"color:#{$color};\"", $text);
	return"<li><a $text>";
}
add_filter('wp_tag_cloud', 'colorCloud', 1); 


/**
 * 替换系统默认表情
 */
add_filter('smilies_src','custom_smilies_src',1,10);
function custom_smilies_src ($img_src, $img, $siteurl){
	return get_bloginfo('template_directory').'/images/smilies/'.$img;
}

/**
 * 公告
 */
function post_type_bulletin() {
register_post_type(
                     'bulletin', 
                     array( 'public' => true,
					 		'publicly_queryable' => true,
							'hierarchical' => false,
                    		'labels'=>array(
    									'name' => _x('公告', 'post type general name'),
    									'singular_name' => _x('公告', 'post type singular name'),
    									'add_new' => _x('添加新公告', '公告'),
    									'add_new_item' => __('添加新公告'),
    									'edit_item' => __('编辑公告'),
    									'new_item' => __('新的公告'),
    									'view_item' => __('预览公告'),
    									'search_items' => __('搜索公告'),
    									'not_found' =>  __('您还没有发布公告'),
    									'not_found_in_trash' => __('回收站中没有公告'), 
    									'parent_item_colon' => ''
  										),
                             'show_ui' => true,
							 'menu_position'=>5,
									'supports' => array(
															'title',
															'author', 
															'excerpt',
															'thumbnail',
															'trackbacks',
															'editor', 
															'comments',
															'custom-fields',
															'revisions'	) ,
							'show_in_nav_menus'	=> true ,
							'taxonomies'		=> array(	'menutype',
															'post_tag')
                                ) 
                      ); 

} 
add_action('init', 'post_type_bulletin');

function create_genre_taxonomy() 
{
  $labels = array(
	  						  'name' => _x( '公告分类', 'taxonomy general name' ),
    						  'singular_name' => _x( 'genre', 'taxonomy singular name' ),
    						  'search_items' =>  __( '搜索分类' ),
   							  'all_items' => __( '全部分类' ),
    						  'parent_item' => __( '父级分类目录' ),
   					   		  'parent_item_colon' => __( '父级分类目录:' ),
   							  'edit_item' => __( '编辑公告分类' ), 
  							  'update_item' => __( '更新' ),
  							  'add_new_item' => __( '添加新公告分类' ),
  							  'new_item_name' => __( 'New Genre Name' ),
  ); 
  register_taxonomy('genre',array('?bulletin'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'genre' ),
  ));
}
add_action( 'init', 'create_genre_taxonomy', 0 );

/**
 * 系统评论输出
 */
function mytheme_comment($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment;
		global $commentcount;
		
		extract($args, EXTR_SKIP);
		
		if ( 'div' == $args['style'] ) {
			$tag = 'div';
			$add_below = 'comment';
		} else {
			$tag = 'li';
			$add_below = 'div-comment';
		}
?>
		
		<<?php echo $tag ?> <?php comment_class(empty( $args['has_children'] ) ? '' : 'parent') ?> id="comment-<?php comment_ID() ?>">
		<?php
		if(!$parent_id = $comment->comment_parent){
			
			switch ($commentcount){
				case 0 :echo "<span class=floor_span>沙发</span>";++$commentcount;break;
				case 1 :echo "<span class=floor_span>椅子</span>";++$commentcount;break;
				case 2 :echo "<span class=floor_span>板凳</span>";++$commentcount;break;
				default:printf('<span class=floor_span>%1$s楼</span>',++$commentcount);
			}
			
		}
		?>
		<?php if ( 'div' != $args['style'] ) : ?>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
		<?php endif; ?>
		<div class="comment-author vcard">
		<span class='author_pic_span'><div class="author_pic"><?php if ($args['avatar_size'] != 0) echo get_avatar( $comment, $args['avatar_size'] ); ?></div></span>
		<?php printf(__('<cite class="fn">%s</cite> <span class="says">says:</span>'), get_comment_author_link()) ?>
		</div>
<?php if ($comment->comment_approved == '0') : ?>
		<em class="comment-awaiting-moderation">您的评论在等待审核</em>
		<br />
<?php endif; ?>

		<div class="comment-meta commentmetadata"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>">
			<?php
				/* translators: 1: date, 2: time */
				printf( __('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link(__('(Edit)'),'  ','' );
			?>
		</div>

		<?php comment_text() ?>

		<div class="reply">
		<?php comment_reply_link(array_merge( $args, array('add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
		</div>
		<?php if ( 'div' != $args['style'] ) : ?>
		</div>
		<?php endif; ?>
<?php
        }

function cut_str($string, $sublen, $start = 0, $code = 'UTF-8')
	{
	 if($code == 'UTF-8')
	 {
	 $pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
	 preg_match_all($pa, $string, $t_string);
	 if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."...";
	 return join('', array_slice($t_string[0], $start, $sublen));
	 }
	 else
	 {
	 $start = $start*2;
	 $sublen = $sublen*2;
	 $strlen = strlen($string);
	 $tmpstr = '';
	 for($i=0; $i<$strlen; $i++)
	 {
	 if($i>=$start && $i<($start+$sublen))
	 {
	 if(ord(substr($string, $i, 1))>129) $tmpstr.= substr($string, $i, 2);
	 else $tmpstr.= substr($string, $i, 1);
	 }
	 if(ord(substr($string, $i, 1))>129) $i++;
	 }
	 if(strlen($tmpstr)<$strlen ) $tmpstr.= "...";
	 return $tmpstr;
	 }
	}function dm_the_thumbnail() {  
  
    global $post;  
  
    //判断缩略图
  
    if ( has_post_thumbnail() ) {  
  
    } else { //查找文章图片
  
        $content = $post->post_content;  
  
        preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);  
  
        $n = count($strResult[1]);  
  
        if($n > 0){ // 提取首图
  
            echo '<a href="'.get_permalink().'"><img src="'.get_option('siteurl').'/wp-content/themes/XLove/thumb.php?w=120&h=90&src='.$strResult[1][0].'" /></a>';  
  
        }else { // 随机图片
  
            echo '<a href="'.get_permalink().'"><img src="'.get_bloginfo('template_url').'/images/random/'.rand(1,13).'.jpg" /></a>';  
  
        }  
  
    } 
} 

/**
 * 显示时间
 */
function smc_time_since($timestamp) {

    $since = abs(time()-$timestamp);

    $gmt_offset = get_option('gmt_offset') * 3600;//获取wordpress的时区偏移值

    $timestamp += $gmt_offset; $current_time = mktime() + $gmt_offset;

    if(floor($since/3600)){

        if(gmdate('Y-m-d',$timestamp) == gmdate('Y-m-d',$current_time)){

            $output = '今天 ';

            $output.= gmdate('H:i:s',$timestamp);

        }else{

            if(gmdate('Y',$timestamp) == gmdate('Y',$current_time)){

                $output = gmdate('m月d日 H:i:s',$timestamp);

            }else{

                $output = gmdate('Y年m月d日 H:i:s',$timestamp);

            }

        }

    }else{

        if(($output=floor($since/60))){

            $output = $output.'分钟前';

        }else $output = '刚刚';

    }

    return $output;

}      
    


