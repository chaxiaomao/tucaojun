<?php
/*
Template Name: images
*/
?>
<?php $options = get_option( 'AesRoom_theme_settings' ); ?>
<?php get_header(); ?>
<?php
	$themeurl = get_bloginfo('template_url');
?>
<?php setPostViews(get_the_ID()); ?>
	<!-- 相册框开始 -->
	<div id="album_container">
		
		<div id="album_menu">
			<p class="list_top"><a class="current_album" href="index_9_1.html" hidefocus="true">美图TOP10</a></p>
			<dl>
				<?php
				$recentPosts = new WP_Query(); 
				$list_number = 1;
				$recentPosts->query("cat='".$options['album_id']."'&showposts=10"); 
				?>
				<ul>
				<?php
				while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>
				<dd>
				<a href="<?php the_permalink() ?>" title="点击查看 <?php the_title(); ?>" rel="bookmark"><span class="album_list"><?php echo $list_number;$list_number++;?></span> <?php the_title(); ?></a>
				</dd>
				<?php endwhile; ?>
			</dl>
		</div>
		<div id="album_panel">
			<ul class="clearfix">
			<?php 
			$post_query = get_posts("category='".$options['album_id']."'&numberposts=15");
			foreach($post_query as $post){
			$PictureAmount=$post->post_content;
			$start = stripos($PictureAmount,"X");
			$count =substr($PictureAmount,$start+1);
		?>
		<li style="position:relative">
			<?php if ( has_post_thumbnail() ) { ?>
				<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><?php the_post_thumbnail(); ?></a><a style="background:none" href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><?php the_title_attribute(); ?></a><span><?php echo $count."张";?></span>
			<?php }else{?>
				<a href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><img src="<?php echo $themeurl ?>/images/<?php echo rand(1,$random)?>.jpg" width="120" height="80"></a><a style="background:none" href="<?php the_permalink(); ?>" title="点击查看 <?php the_title(); ?>"><?php the_title_attribute(); ?></a><span><?php echo $count."张";?></span>
			<?php }?>
			
		</li>
		<?php }?>
  </ul>
</div>
</div>
<?php get_footer(); ?>